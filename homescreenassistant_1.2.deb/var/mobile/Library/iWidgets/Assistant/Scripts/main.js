
var updateWeatherEvery = updateInterval*60*1000;
var xmldata = false;
var postal;
var filename = "";
var where = "";
var whereOld = "";
var refreshLocationTimer;
var updateTimer = 0;
var zip;
var forecastdisplay = true;
var page = 3;
var swf = setInterval(function(){swtch()}, rotint * 1000);


switch (lang) {
case "fr":
	var days = ["Dim","Lun","Mar","Mer","Jeu","Ven","Sam"];
	var months=['Jan','Fev','Mar','Avr','Mai','Jui','Jui','Aou','Sep','Oct','Nov','Dec'];
break;
case "de":
	var days = ["Son","Mon","Die","Mit","Don","Fre","Sam"];
	var months=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September ","Oktober","November","Dezember"];	    
break;
case "sp":
	var days = ["Dom","Lun","Mar","Mie","Jue","Vie","Sab"];
	var months=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
break;
case "it":
	var days = ["Dom","Lun","Mar","Mer","Gio","Ven","Sab"];
	var months=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
break;
default: 
	var days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
	var months=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
break;
}

function updateClock() {
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentYear = currentTime.getFullYear();
timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
	
if (ampm == false) {
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
	}
if (ampm == true) {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}

document.getElementById("hour").innerHTML = currentHours;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("ampm").innerHTML = timeOfDay;
document.getElementById("second").innerHTML = currentSeconds;
document.getElementById("year").innerHTML = currentYear;

if (lang == "am") {
	document.getElementById("weekday").innerHTML = days[currentTime.getDay()] ;
	document.getElementById("month").innerHTML = months[currentTime.getMonth()] ;
	document.getElementById("date").innerHTML = currentDate;
	} else {
	document.getElementById("weekday").innerHTML = days[currentTime.getDay()] ;
	document.getElementById("date").innerHTML = currentDate; // DONT WORRY ! IT'S NORMAL
	document.getElementById("month").innerHTML =  months[currentTime.getMonth()];
	}

if (currentTime.getTime() - updateTimer >= updateWeatherEvery) {
	if (updateTimer == 0) {
		if (gps == true) { UpdateLocation(); } else { validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal); }
		} else {
		zip = locale;
		weatherRefresherTemp(zip);
		}
	updateTimer = currentTime.getTime();
	}

}
 
 


function touchEnd(event){
clearInterval(swf);
swtch();
Battery();
swf = setInterval(function(){swtch()}, rotint * 1000);
}
function touchEnd2(event){
page = "clear"
clearInterval(swf);
swtch();
swf = setInterval(function(){swtch()}, 9999 * 1000);
}


function swtch() {
if ( page === "clear" ) {
	 $( "#lvl" ).animate({
    opacity: 0,
  }, 400,"easeInExpo");
  $( "#ClockWidget" ).animate({
    opacity: 0,
  }, 400,"easeInExpo");
	   		$( "#BatteryIcon" ).delay(400).animate({
    height: 1,
    bottom: 10,
    width: 1,
    left: 55,
    opacity: 0
  }, 500);
       		$( "#Batteryoverlay" ).delay(400).animate({
    height: 1,
    bottom: 10,
    width: 1,
    left: 55,
    opacity: 0
  }, 500);
		$( "#Overlay" ).delay(400).animate({
    height: 0,
    top: 70,
    width: 0,
    left: 55
  }, 500);
  	$( "#currentforecast" ).animate({
    height: 10,
    top: 60,
    width: 10,
    fontSize: 1,
    left: 55,
    opacity: 0
  }, 500);
  $( "#Day0Icon, #Day1Icon, #Day2Icon" ).animate({
    height: 5,
    width: 5,
    opacity: 0,
  }, 500,"easeInExpo");
            $( "#Day0, #Day1, #Day2, #Day0HiLo, #Day1HiLo, #Day2HiLo" ).animate({
    fontSize: 1,
    opacity: 0,
  }, 500,"easeInExpo");
  $( "#forecast" ).animate({
    height: 10,
    top: 60,
    width: 10,
    left: 55,
    width: 10,
    fontSize: 1,
    opacity: 0
  }, 500);
  	    		$( "#currentconditions" ).animate({
    height: 10,
    top: 55,
    width: 10,
    left: 55,
    fontSize: 1,
    opacity: 0,
  }, 500);
	  		$( "#weathericon" ).animate({
    height: 0,
    top: 65,
    width: 0,
    left: 55,
    opacity: 0,
  }, 500);
  
  page = 3;
  }
  
if ( page === 1 ) {

	 $( "#lvl" ).animate({
    opacity: 0,
  }, 400,"easeInExpo");
  $( "#ClockWidget" ).animate({
    opacity: 0,
  }, 400,"easeInExpo");
	   		$( "#BatteryIcon" ).delay(400).animate({
    height: 1,
    bottom: 10,
    width: 1,
    left: 55,
    opacity: 0
  }, 500);
       		$( "#Batteryoverlay" ).delay(400).animate({
    height: 1,
    bottom: 10,
    width: 1,
    left: 55,
    opacity: 0
  }, 500);
		$( "#Overlay" ).delay(400).animate({
    height: 0,
    top: 70,
    width: 0,
    left: 55
  }, 500);
		$( "#Overlay" ).animate({
    height: 140,
    top: 0,
    width: 210,
    left: 90
  }, 1000,"easeInExpo");
    $( "#currentforecast" ).delay(900).animate({
    height: 130,
    top: 5,
    width: 200,
    left: 100,
    fontSize: 15,
    opacity: 1,
  }, 1000,"easeInExpo");	
      $( "#forecast" ).delay(900).animate({
    height: 85,
    top: 68,
    left: 60,
    width: 270,
    left: 60,
    fontSize: 11,
    opacity: 1,
  }, 1000,"easeInExpo");
        $( "#Day0Icon, #Day1Icon, #Day2Icon" ).delay(900).animate({
    height: 50,
    width: 50,
    opacity: 1,
  }, 1000,"easeInExpo");
          $( "#Day0, #Day1, #Day2, #Day0HiLo, #Day1HiLo, #Day2HiLo" ).delay(900).animate({
    fontSize: 11,
    opacity: 1,
  }, 1000,"easeInExpo");
 	$( "#dummy" ).stop().animate({
    opacity: 0,
  }, 1900);
	

	 page = 2 ;
} else if ( page === 2 ) {

	$( "#currentforecast" ).animate({
    height: 10,
    top: 60,
    width: 10,
    fontSize: 1,
    left: 55,
    opacity: 0
  }, 500);
  $( "#Day0Icon, #Day1Icon, #Day2Icon" ).animate({
    height: 5,
    width: 5,
    opacity: 0,
  }, 500,"easeInExpo");
            $( "#Day0, #Day1, #Day2, #Day0HiLo, #Day1HiLo, #Day2HiLo" ).animate({
    fontSize: 1,
    opacity: 0,
  }, 500,"easeInExpo");
  $( "#forecast" ).animate({
    height: 10,
    top: 60,
    width: 10,
    left: 55,
    width: 10,
    fontSize: 1,
    opacity: 0
  }, 500);
          
	$( "#Overlay" ).animate({
    height: 0,
    top: 70,
    width: 0,
    left: 55
  }, 500);
		$( "#Overlay" ).animate({
    height: 120,
    top: 10,
    width: 210,
    left: 90,
  }, 1000,"easeInExpo");
  		$( "#weathericon" ).delay(500).animate({
    height: 55,
    top: 75,
    width: 55,
    left: 225,
    opacity: 1,
  }, 1000,"easeInExpo");
    		$( "#currentconditions" ).delay(500).animate({
    height: 125,
    top: 15,
    width: 200,
    left: 100,
    fontSize: 15,
    opacity: 1,
  }, 1000,"easeInExpo");
  	    		$( "#dummy" ).stop().animate({
    opacity: 0,
  }, 1500);

	page = 3;
	
	} else if ( page === 3 ) {
jQuery.get('file:///private/var/mobile/Library/BatteryStats.txt', function(appdata) {
var myvar = appdata;
var substr = appdata.split('\n');
var Level=substr[0].split(':')[1];
var fill = Level * (65/100);

	    		$( "#currentconditions" ).animate({
    height: 10,
    top: 55,
    width: 10,
    left: 55,
    fontSize: 1,
    opacity: 0,
  }, 500);
	  		$( "#weathericon" ).animate({
    height: 0,
    top: 65,
    width: 0,
    left: 55,
    opacity: 0,
  }, 500);

	$( "#Overlay" ).animate({
    height: 0,
    top: 65,
    width: 0,
    left: 55
  }, 500);
		$( "#Overlay" ).animate({
    height: 140,
    top: 0,
    width: 60,
    left: 90
  }, 1000,"easeInExpo");
  		$( "#BatteryIcon" ).delay(500).animate({
    height: fill/3,
    bottom: -8,
    width: 30,
    left: 105,
    opacity: 0.67
  }, 1000,"easeInExpo");
  		$( "#Batteryoverlay" ).delay(500).animate({
    height: 71,
    bottom: -10,
    width: 33,
    left: 103,
    opacity: 1
  }, 1000,"easeInExpo");
  $( "#lvl" ).delay(1400).animate({
    opacity: 1
  }, 600,"easeInExpo");
  $( "#ClockWidget" ).delay(1400).animate({
    opacity: 1
  }, 600,"easeInExpo");
    		$( "#BatteryIcon" ).animate({
    height: fill,
  }, 1000);
	});
	page = 1;
	
	$( "#dummy" ).stop().animate({
    opacity: 0,
  }, 2500);
	}
	
}

function Battery() {
refreshBatteryTimer = setTimeout(Battery, 15*1000);
jQuery.get('file:///private/var/mobile/Library/BatteryStats.txt', function(appdata) {
var myvar = appdata;
var substr = appdata.split('\n');
var Level=substr[0].split(':')[1];
var State=substr[1].split(':')[1];
document.getElementById("lvl").innerHTML = Level +"%";
var bsrc = "Images/" + barn + ".png"
document.getElementById("Batteryoverlay").src = bsrc;
var xyz = document.getElementById("BatteryIcon");

if( bfill === "cc" ) {
if( Level >= 0  && Level <= 17 )  {xyz.src = "Images/Battery Fills/6.png";}
if( Level >= 18  && Level <= 34 )  {xyz.src = "Images/Battery Fills/5.png";}
if( Level >= 35  && Level <= 50 )  {xyz.src = "Images/Battery Fills/4.png";}
if( Level >= 51  && Level <= 67 )  {xyz.src = "Images/Battery Fills/3.png";}
if( Level >= 69  && Level <= 83 )  {xyz.src = "Images/Battery Fills/2.png";}
if( Level >= 84  && Level <= 100 )  {xyz.src = "Images/Battery Fills/1.png";}}
else { xyz.src = "Images/Battery Fills/"+bfill+".png";}
});}



function setPostal(obj){
	if (obj.error == false){
		if(obj.cities.length > 0) {
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
			convertWoeid();
			}
			else
			{
			document.getElementById("city").innerHTML="Locale ?!";
			}
		}
		else
		{
		document.getElementById("city").innerHTML="Locale ?!";
		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
		}
}

function weatherRefresherTemp(zip){
	fetchWeatherData(dealWithWeather, zip);
}

function validateWeatherLocation (location, callback) {
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location};
	callback (obj);
}

function dealWithWeather(obj){
	if (obj.error == false){
		document.getElementById("city").className= TextColor;
		document.getElementById("city").innerHTML= obj.city;
		document.getElementById("desc").innerHTML = obj.description;
		document.getElementById("temp").innerHTML = obj.temp + "\u00B0";
	document.getElementById("currentconditions").innerHTML = "You are in " + obj.city + ", and it is currently "+obj.temp+" degrees. The conditions outside are " +obj.description.toLowerCase() + ".";

		if ( gps == true) {
		document.getElementById("coordinates").className = "TextColorGrey";
		document.getElementById("coordinates").innerHTML = " [" + textLat + " " + textLong + "]";
		} else {
		document.getElementById("coordinates").innerHTML = " ";
		}

		switch (lang) {
		case "fr":
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Ensoleill&eacute;'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Bruine'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Fortes chutes de neige'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Fortes averses'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Ciel d&eacute;gag&eacute;';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Quelques nuages';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Partiellement nuageux';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nuages &eacute;parses';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;rement voil&eacute;';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Brume'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nuageux';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Brouillard';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Averses';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Soleil et averses';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Orages';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Orage';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et fortes averses';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Soleil et fortes averses';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re pluie';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Pluie';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Averses de neige';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux avec neige';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Soleil et averses de neige';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Averses de neige';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Averses de neige';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Neige';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et neige';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Glace';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Verglas';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Pluie vergla&ccedil;ante';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Chaud';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Froid';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Vent';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Clair';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Tr&egrave;s clair';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Partiellement nuageux';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Brume';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et averses';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et averses';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et fortes averses';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Brouillard';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Flocons de neige'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;res chutes de neige'; } 
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Averses';    }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re bruine';	  }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Pluie et verglas';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Neige et verglas';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Gros orages';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Ouragan';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Orage tropical';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornade';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Buine vergla&ccedil;ante';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Rafales de neige'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Gr&ecirc;le'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Poussi&eacute;reux';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Brumeux';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Temp&ecirc;te';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Pluie et Gr&ecirc;le m&eacute;l&eacute;es';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Orages isol&eacute;s';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Averses isol&eacute;s';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Orages &eacute;parses';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Averses &eacute;parses';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Chutes de neige &eacute;parses';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Pluie l&eacute;g&egrave;re et &eacute;clairs';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Non disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Neige poudreuse et vent';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re averse'; }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Tonnerre'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et vent'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Rafales de vent'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Sable'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable et vent'; }
			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='Rafales'; }
			document.getElementById("currentconditions").innerHTML = "Vous êtes dans " + obj.city + ", et il est actuellement " + obj.temp+ " degrés. Les conditions sont à l'extérieur "+document.getElementById("desc").innerHTML.toLowerCase()+".";
			document.getElementById("currentforecast").innerHTML = "C'est ce que votre temps ressemble pour les prochains jours.";
		break;
		case "de":
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado!'; }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tropischer Sturm'; }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Wirbelsturm'; }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Schwere Gewitter'; }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Regen und Schnee'; }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Graupelschauer'; }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Gefrierender Nieselregen'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Nieselregen'; }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Gefrierender Regen'; }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Schauer'; }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Schneegest&ouml;ber'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }
			if (translatedesc=='light snow grains') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Schneetreiben'; }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Schnee'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Hagel'; }
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Staubig'; }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Nebelig'; }
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Dunstschleier'; }
			if (translatedesc=='smoky') { document.getElementById("desc").innerHTML='Dunstig'; }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='St&uuml;rmisch'; }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Windig'; }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Kalt'; }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Bew&ouml;lkt'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Meist Bew&ouml;lkt'; }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt'; }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Klar'; }
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Sonnig'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Heiter'; }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Regen und Hagel'; }
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Heiss'; }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='&Ouml;rtliche Gewitter'; }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Vereinzelte Gewitter'; }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Vereinzelte Schauer'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Starker Schneefall'; }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Vereinzelte Schneeschauer'; }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt'; }
			if (translatedesc=='thundershowers') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Scheeschauer'; }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Ouml;rtliche Gewitterschauer'; }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Leichte Regenschauer'; }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='nicht verfuegbar'; }
			if (translatedesc=='showers in the vicinity') { document.getElementById("desc").innerHTML='Schauer'; }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Teilweise Sonnig'; }
			if (translatedesc=='ground fog') { document.getElementById("desc").innerHTML='Bodennebel'; }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='Leichter Nieselregen'; }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Leichter Regen'; }
			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Nebel'; }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Nebel'; }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Regen'; }
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Regenschauer'; }
			if (translatedesc=='severe thunderstorm/windy') { document.getElementById("desc").innerHTML='Schwere Gewitter/Windig'; }
			document.getElementById("currentconditions").innerHTML = "Sie sind in " + obj.city + ", und es ist derzeit " + obj.temp + " Grad. Die Bedingungen draußen sind "+document.getElementById("desc").innerHTML.toLowerCase()+".";
			document.getElementById("currentforecast").innerHTML = "Dies ist, was Ihre Wetter sieht für die nächsten paar Tage.";
		break;
		case "sp":
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Soleado'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Llovizna'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Nieve fuerte'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Luvia fuerte'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Lluvia y nieve'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Mezcla de lluvia y nieve'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Despejado';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Mayormente soleado';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Parcialmente soleado';	 }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Intermitente nublado';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Sol brumoso';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Bruma'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Mayormente nublado';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nublado';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Niebla';   }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Chubascos';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Parcialmente soleado con chubascos';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Tormenta electrica';	}
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Mayormente nublado con tormentas de chubascos';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Parcialmente soleado con tormentas de chubascos';	  }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Lluvia ligera';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Lluvia';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Rafagas';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Mayormente nublado con rafagas';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Parcialmente soleado con rafagas';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Rafagas de nieve';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Precipitaciones de nieve';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Nieve';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Mayormente nublado con nieve';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Hielo';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Aguanieve';	}
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Lluvia bajo cero';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Mezcla de lluvia y nieve';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Caluroso';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Frio';	 }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Vientoso';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Despejado';	}
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Mayormente despejado';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Parcialmente despejado';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Bruma';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Parcialmente nublado con chubascos';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Mayormente nublado con chubascos';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parcialmente nublado con tormentas de chubascos';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Neblina';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Nieve ligera'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Ligeras precipitaciones de nieve'; }	 
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Precipitaciones de lluvia';    }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Bruma';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Mezcla de lluvia y aguanieve';	  }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Mezcla de nieve y aguanieve';	 }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas severas';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Huracan';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tormenta tropical';	 }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Llovizna helada';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Viento y nieve'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Granizo'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Polvareda';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Humeado';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Tempestuoso';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Mezcla de lluvia y granizo';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas aisladas';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Tormentas aisladas';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas dispersas';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Chubascos dispersos';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Precipitaciones de nieve dispersas';	  }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='LLuvia y tormenta ligera';	 }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='No disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Acumulacion de nieve y viento';	  }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Precipitaciones de lluvia ligera';   }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Truenos'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Mayormente nublado y ventoso'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Tormentas de arena'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Chubascos y viento'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Arena'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Tormentas de arena y ventoso'; }
		document.getElementById("currentconditions").innerHTML = "Usted está en " + obj.city + ", dove è " +obj.temp+ " grados. Las condiciones externas son "+document.getElementById("desc").innerHTML.toLowerCase()+".";
			document.getElementById("currentforecast").innerHTML = "Esto es lo que se ve su clima como por los próximos días.";
		break;
		case "it":
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Soleggiato'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Pioggerella'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Forti nevicate'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Forti piogge'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Vevischio'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Misto pioggia e neve'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Sereno';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Molto soleggiato';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Parzialmente soleggiato';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nuvoloso a tratti';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Sole coperto'; }
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Nebbia'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Molto nuvoloso';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nuvoloso';	}
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Nebbia';   }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Diluvio';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Soleggiato con pioggia';	 }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Fulmini';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Tuoni';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Molto Nuvoloso con pioggia e fulmini';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Possibili Piogge';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Pioggia leggera';   }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Pioggia';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Nevischio'; }
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Nuvoloso con nevischio';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Parzialmente soleggiato con neve';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Raffiche di neve';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Precipitazioni nevose';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Neve';	  }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Molto nuvoloso con neve';	}
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Ghiaccio';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Nevischio';	}
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Grandine';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Pioggia e neve'; }
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Caldo';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Freddo';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Ventoso';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Sereno';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Molto sereno';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Parzialmente nuvoloso';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Velato';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Cielo velato';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Nuvoloso a tratti';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parzialmente nuvoloso con raffiche';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Nebbiolina';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Neve leggiera'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Poca neve'; }	  
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Forti precipitazioni';	 }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Freddino';	 }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Misto pioggia e nevischio';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Misto neve e nevischio';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Tuoni e fulmini';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Uragano';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tempesta tropicale';	  }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Grandine';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Vento e neve'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Grandine'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Polvere';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Humeado';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Tempesa';	 }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='misto neve e grandine';	  }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Fulmini isolati';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Temporali isolati';	  }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Tempesta di fulmini';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Tempesta di pioggia';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Neve sparsa';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Pioggia leggera con fulmini';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='No disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Troppa neve';	}
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Piccole precipitazioni';	  }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Tuoni'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Molto nuvoloso con vento'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Tormenta'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Pioggia e vento'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Arena'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Tormenta ventosa'; }
			document.getElementById("currentconditions").innerHTML = "Tu sei in " + obj.city + ", ed è attualmente " + obj.temp + " gradi. Le condizioni sono al di fuori "+document.getElementById("desc").innerHTML.toLowerCase()+".";
			document.getElementById("currentforecast").innerHTML = "Questo è ciò che il vostro tempo assomiglia per i prossimi giorni.";
		break;
		default:		       
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='sunny'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Bruine'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Fortes chutes de neige'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Fortes averses'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Ciel d&eacute;gag&eacute;';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Quelques nuages';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Partiellement nuageux';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nuages &eacute;parses';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;rement voil&eacute;';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Brume'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nuageux';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Brouillard';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Averses';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Soleil et averses';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Orages';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Orage';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et fortes averses';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Soleil et fortes averses';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re pluie';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Pluie';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Averses de neige';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux avec neige';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Soleil et averses de neige';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Averses de neige';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Averses de neige';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Neige';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et neige';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Glace';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Verglas';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Pluie vergla&ccedil;ante';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Chaud';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Froid';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Vent';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Clair';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Tr&egrave;s clair';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Partiellement nuageux';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Brume';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et averses';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et averses';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et fortes averses';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Brouillard';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Flocons de neige'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;res chutes de neige'; } 
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Averses';    }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re bruine';	  }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Pluie et verglas';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Neige et verglas';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Gros orages';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Ouragan';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Orage tropical';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornade';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Buine vergla&ccedil;ante';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Rafales de neige'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Gr&ecirc;le'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Poussi&eacute;reux';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Brumeux';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Temp&ecirc;te';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Pluie et Gr&ecirc;le m&eacute;l&eacute;es';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Orages isol&eacute;s';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Averses isol&eacute;s';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Orages &eacute;parses';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Averses &eacute;parses';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Chutes de neige &eacute;parses';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Pluie l&eacute;g&egrave;re et &eacute;clairs';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Non disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Neige poudreuse et vent';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re averse'; }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Tonnerre'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et vent'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Rafales de vent'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Sable'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable et vent'; }
			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='Rafales'; }
		break;
		break;
		}		
     // WEATHER CONDITION OBVIOUSLY
		document.getElementById("weathericon").src= "Icons/" + icons + "/" + obj.icon +".png"; 
		document.getElementById("Day0").innerHTML=obj.forecastday[0]
		document.getElementById("Day0Icon").src= "Icons/" + icons + "/" + obj.forecastcode[0] +".png";
		document.getElementById("Day0HiLo").innerHTML=obj.forecastlow[0] + "\u00B0" + "/ " + obj.forecasthigh[0] + "\u00B0";
		document.getElementById("Day1").innerHTML=obj.forecastday[1]
		document.getElementById("Day1Icon").src= "Icons/" + icons + "/" + obj.forecastcode[1] +".png";
		document.getElementById("Day1HiLo").innerHTML=obj.forecastlow[1] + "\u00B0" + "/ " + obj.forecasthigh[1] + "\u00B0";
		document.getElementById("Day2").innerHTML=obj.forecastday[2]
		document.getElementById("Day2Icon").src= "Icons/" + icons + "/" + obj.forecastcode[2] + ".png";
		document.getElementById("Day2HiLo").innerHTML=obj.forecastlow[2] + "\u00B0" + "/ " + obj.forecasthigh[2] + "\u00B0";
		
		var transday0 = nameday(obj.forecastday[0]);
		document.getElementById("Day0").innerHTML= transday0;
		var transday1 = nameday(obj.forecastday[1]);
		document.getElementById("Day1").innerHTML= transday1;
		var transday2 = nameday(obj.forecastday[2]);
		document.getElementById("Day2").innerHTML= transday2;
	}
	else
	{
	document.getElementById("city").innerHTML = "Internet ?!";
	}
}
function nameday(day) {
switch (lang) {
case "fr":
	switch (day){
	    case "Sun":
        { return "Dim"; }
	    case "Mon":
        { return "Lun"; }
        case "Tue":
        { return "Mar"; }
	    case "Wed":
        { return "Mer"; }
        case "Thu":
        { return "Jeu"; }
	    case "Fri":
        { return "Ven"; }
        case "Sat":
        { return "Sam"; }}
break;
case "de":
	switch (day){
	    case "Sun":
        { return "Son"; }
	    case "Mon":
        { return "Mon"; }
        case "Tue":
        { return "Die"; }
	    case "Wed":
        { return "Mit"; }
        case "Thu":
        { return "Don"; }
	    case "Fri":
        { return "Fre"; }
        case "Sat":
        { return "Sam"; }}
break;
case "sp":
	switch (day){
	    case "Sun":
        { return "Dom"; }
	    case "Mon":
        { return "Lun"; }
        case "Tue":
        { return "Mar"; }
	    case "Wed":
        { return "Mie"; }
        case "Thu":
        { return "Jue"; }
	    case "Fri":
        { return "Vie"; }
        case "Sat":
        { return "Sab"; }}
break;
case "it":
	switch (day){
	    case "Sun":
        { return "Dom"; }
	    case "Mon":
        { return "Lun"; }
        case "Tue":
        { return "Mar"; }
	    case "Wed":
        { return "Mer"; }
        case "Thu":
        { return "Gio"; }
	    case "Fri":
        { return "Ven"; }
        case "Sat":
        { return "Sab"; }}
break;
case "en":
	switch (day){
	    case "Sun":
        { return "Sun"; }
	    case "Mon":
        { return "Mon"; }
        case "Tue":
        { return "Tue"; }
	    case "Wed":
        { return "Wed"; }
        case "Thu":
        { return "Thu"; }
	    case "Fri":
        { return "Fri"; }
        case "Sat":
        { return "Sat"; }}
break;
}}

function findChild (element, nodeName) {
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	return null;
}

function convertWoeid () {
		zip = locale;
		weatherRefresherTemp(zip);
}


// Get data with woeid (no GPS)
function fetchWeatherData (callback, zip) {
var temp = 1;
if (tempUnit == "c") { temp = 1 } else { temp = 2};
	var url="http://apple.accuweather.com/adcbin/apple/Apple_Weather_Data.asp?zipcode=" + zip + "&metric=" + temp;
$.get(url, function (data) {
        xmldata = true;
        obj = {error: false};
        $(data).find('CurrentConditions').each(function () {
            if (gps == false) {
                obj.city = $.trim($(this).find('City').text());
                if (zip.indexOf('|') != -1) { // ONLY FOR ZIP OUT OF USA
                    tempzip = zip.split('|');
                    obj.coordinates = tempzip[3].substr(0, 15);
                } else {
                    obj.coordinates = zip;
                }
            } else {
                obj.city = city;
                obj.coordinates = textLat + " " + textLong;
            }
            obj.windspeed = $.trim($(this).find('WindSpeed').text()) * 1;
            obj.humidity = $.trim($(this).find('Humidity').text());
            obj.icon = convertAccuIcon($.trim($(this).find("WeatherIcon").text()) * 1);
            obj.winddir =  $.trim($(this).find('WindDirection').text());
            obj.rising = $.trim($(this).find('Pressure').attr('state'));
            obj.visibility = $.trim($(this).find('Visibility').text()) * 1;
            obj.UVIndex = $.trim($(this).find('UVIndex').text());
            if (tempUnit == 1) {
                obj.pressure = Math.round($.trim($(this).find('Pressure').text()) * 33.8638864);
            } else {
                obj.pressure = $(this).find('Pressure').text();
            }
            obj.realFeel = $.trim($(this).find('RealFeel').text());
            obj.temp = $.trim($(this).find('Temperature').text());
            obj.description = $.trim($(this).find('WeatherText').text());
        });
		
		
        obj.moondesc = [];
        obj.moondate = [];
        obj.moonphase = [];
        var t = 0; 
        $(data).find('Phase').each(function () {
        obj.moondesc[t] = $.trim($(this).attr('text'));
        obj.moondate[t] = $.trim($(this).attr('date')); 
        obj.moonphase[t] = $.trim($(this).text());
        t++;
        });
		
        obj.sunrise =  $.trim($(data).find('Sun').attr('rise'));
        obj.sunset = $.trim($(data).find('Sun').attr('set'));
        obj.moonrise =  $.trim($(data).find('Moon').attr('rise'));
        obj.moonset = $.trim($(data).find('Moon').attr('set'));
        obj.forecastday = [];
        obj.forecasthigh = [];
        obj.forecastlow = [];
        obj.forecastreallow = [];
        obj.forecastrealhigh = [];
        obj.forecastcode = [];
        var i = 0;
        $(data).find('day').each(function () {
            obj.forecastday[i] = $.trim($(this).find("DayCode").text()).substring(0, 3);
            obj.forecastlow[i] = $.trim($(this).find("Low_Temperature").text());
            obj.forecasthigh[i] = $.trim($(this).find("High_Temperature").text());
            obj.forecastreallow[i] = $.trim($(this).find("Low_Temperature").text());
            obj.forecastrealhigh[i] = $.trim($(this).find("Real_Feel_High").text());
            obj.forecastcode[i] = convertAccuIcon($.trim($(this).find("WeatherIcon").text()) * 1);
            i++;
        });
        if (obj.description == "Unknown") {
            obj.description = obj.forecasttext[0];
            obj.icon = obj.forecastcode[0];
        }
        obj.pressureunit = (tempUnit == 0) ? "in" : "mb";
        obj.visibilityunit = (tempUnit == 0) ? "mi" : "km";
        obj.windunit =  (tempUnit == 0) ? "mph" : "km/h";

        callback(obj);

    }).fail(function () {
        if (xmldata == true) {
            document.getElementById("coordinates").className = "TextColorRed";
            document.getElementById("coordinates").innerHTML = "OFFLINE";
        } else {
            callback({error: true});
        }
    });
} // End of fetchWeatherData function

function convertAccuIcon(icon) {
    switch (icon) {
    case 1:
        { return 32; }
    case 2:
        { return 34; }
    case 3:
        { return 34; }
    case 4:
        { return 30; }
    case 5:
        { return 21; }
    case 6:
        { return 28; }
    case 7:
        { return 26; }
    case 8:
        { return 26; }
    case 9:
        { return 48; }
    case 10:
        { return 48; }
    case 11:
        { return 20; }
    case 12:
        { return 11; }
    case 13:
        { return 39; }
    case 14:
        { return 39; }
    case 15:
        { return 38; }
    case 16:
        { return 37; }
    case 17:
        { return 37; }
    case 18:
        { return 40; }
    case 19:
        { return 13; }
    case 20:
        { return 14; }
    case 21:
        { return 14; }
    case 22:
        { return 16; }
    case 23:
        { return 16; }
    case 24:
        { return 8; }
    case 25:
        { return 18; }
    case 26:
        { return 10; }
    case 27:
        { return 48; }
    case 28:
        { return 48; }
    case 29:
        { return 5; }
    case 30:
        { return 36; }
    case 31:
        { return 25; }
    case 32:
        { return 24; }
    case 33:
        { return 31; }
    case 34:
        { return 33; }
    case 35:
        { return 29; }
    case 36:
        { return 29; }
    case 37:
        { return 21; }
    case 38:
        { return 27; }
    case 39:
        { return 45; }
    case 40:
        { return 45; }
    case 41:
        { return 47; }
    case 42:
        { return 47; }
    case 43:
        { return 46; }
    case 44:
        { return 46; }
    }
}

