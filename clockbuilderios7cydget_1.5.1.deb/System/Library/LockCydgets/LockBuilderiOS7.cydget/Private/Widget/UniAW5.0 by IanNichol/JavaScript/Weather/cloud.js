// Cloudy condition
// UniAW5.0 By Ian Nicoll with credit to Dacal

var NUMBER_OF_CLOUDS = 12; // clouds to show on screen
var NUMBER_OF_IMAGES = 17; // images + 1
var container = document.getElementById("cloudContainer");
if (where == "day") {
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='none';
} else {
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='none';
}
document.getElementById("weatherWall").style.display='block';

for (var i = 0; i < NUMBER_OF_CLOUDS; i++)
{
container.appendChild(createACloud())
}

function randomInteger(low, high) {
    return low + Math.floor(Math.random() * (high - low));
}
function randomFloat(low, high) {
    return low + Math.random() * (high - low);
}
function pixelValue(value) {
    return value + "px";
}
function durationValue(value) {
    return value + "s";
}
function createACloud() {
    var cloudDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "Images/Weather/cloud/" + where + "/cloud" + randomInteger(1, NUMBER_OF_IMAGES) + ".png";
    cloudDiv.style.top = pixelValue(randomInteger(-55, 25));
    cloudDiv.style.left = pixelValue(randomInteger(-220, -40));
    cloudDiv.style.webkitAnimationName = "fade, float";
    var fadeAndfloatDuration = durationValue(randomFloat(40, 100));
    cloudDiv.style.webkitAnimationDuration = fadeAndfloatDuration + ", " + fadeAndfloatDuration;
    cloudDiv.appendChild(image);
    return cloudDiv;
}
