
 function init ()
 {
   timeDisplay = document.createTextNode ( "" );
   document.getElementById("clock").appendChild ( timeDisplay );
 }
updateClock();
 setInterval('updateClock()', 1000 );
function updateClock()

 {
   var TwentyFourHourClock = $.cookie("24hrcookie"); 
   
if (TwentyFourHourClock == "true"){


   var currentTime = new Date ( );
   var currentHours = currentTime.getHours ( );

   var currentMinutes = currentTime.getMinutes ( );

   var currentSeconds = currentTime.getSeconds ( );

   currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;

   currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;

   var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";

   currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

   currentHours = ( currentHours == 0 ) ? 12 : currentHours;

   var currentTimeString = currentHours + ":" + currentMinutes;

   document.getElementById("clock").firstChild.nodeValue = currentTimeString;
  
 }

if (TwentyFourHourClock == "false"){

   var currentTime = new Date ( );
   var currentHours = currentTime.getHours ( );

   var currentMinutes = currentTime.getMinutes ( );

  var currentSeconds = currentTime.getSeconds ( ); currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  var currentTimeString = currentHours + ":" + currentMinutes;

   document.getElementById("clock").firstChild.nodeValue = currentTimeString;
 

}

}
 





 function init2 ( )

 {

   timeDisplay = document.createTextNode ( "" );

   document.getElementById("ampm").appendChild ( timeDisplay );

 }



 function amPm ( )

 {

   var currentTime = new Date ( );



   var currentHours = currentTime.getHours ( );




   var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";




   currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;




   currentHours = ( currentHours == 0 ) ? 12 : currentHours;





   var currentTimeString = timeOfDay;



   

   document.getElementById("ampm").firstChild.nodeValue = currentTimeString;

 }



 function init3 ( )

 {

   timeDisplay = document.createTextNode ( "" );

   document.getElementById("calendar").appendChild ( timeDisplay );

 }



 function calendarDate ( )

 {

   var this_weekday_name_array = new Array("Sun","Mon","Tues","Wed","Thur","Fri","Sat")

   var this_month_name_array = new Array("Jan","Feb","Mar","Apr","May","June","July","Aug","Sept","Oct","Nov","Dec")  //predefine month names



   var this_date_timestamp = new Date()



   var this_weekday = this_date_timestamp.getDay()

   var this_date = this_date_timestamp.getDate()

   var this_month = this_date_timestamp.getMonth()



   document.getElementById("calendar").firstChild.nodeValue = this_weekday_name_array[this_weekday] + ", " + this_month_name_array[this_month] + " " + this_date  //concat long date string

 }



