

$(window).load(function () {
    //This first part of the code is just the plugin. Ignore it and scroll down!

    /**
     * jQuery Cookie plugin
     *
     * Copyright (c) 2010 Klaus Hartl (stilbuero.de)
     * Dual licensed under the MIT and GPL licenses:
     * http://www.opensource.org/licenses/mit-license.php
     * http://www.gnu.org/licenses/gpl.html
     *
     */
    jQuery.cookie = function (key, value, options) {

        // key and at least value given, set cookie...
        if (arguments.length > 1 && String(value) !== "[object Object]") {
            options = jQuery.extend({}, options);

            if (value === null || value === undefined) {
                options.expires = -1;
            }

            if (typeof options.expires === 'number') {
                var days = options.expires,
                    t = options.expires = new Date();
                t.setDate(t.getDate() + days);
            }

            value = String(value);

            return (document.cookie = [
            encodeURIComponent(key), '=',
            options.raw ? value : encodeURIComponent(value),
            options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
            options.path ? '; path=' + options.path : '',
            options.domain ? '; domain=' + options.domain : '',
            options.secure ? '; secure' : ''].join(''));
        }

        // key and possibly options given, get cookie...
        options = value || {};
        var result, decode = options.raw ? function (s) {
                return s;
            } : decodeURIComponent;
        return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null;
    };

    //------------------------------------------------END of plugin!---------------------------------




    //------------------------------------------------Start Widget control---------------------------------

    $("#widgets").click(function () {
        closemenu();
submenu();
    


      $(".mainwidgets").css('left', '0px');
      $(".mainwidgets").css('top', '-40px');

        $("#widgetclosemenu").css('left', '55px');
        $("#widgetclosemenu").css('top', '270px');
   
        $("#widgetone").css('left', '55px');
        $("#widgettwo").css('left', '55px');
        $("#widgetfour").css('left', '55px');
        $("#widgetthree").css('left', '55px');
        $("#widgetone").css('top', '104px');
        $("#widgettwo").css('top', '160px');
        $("#widgetthree").css('top', '215px');
        $("#widgetfour").css('top', '290px');//took out
    });
tap="0";
    $("#iframetwo").click(function () {
        tap++
        if(tap=="2"){
        $("#iframetwo").css('left', '500px');
        tap="0";
    }
    });




    $("#widgetone").click(function () {
        closemenu();
        closepanels();
createwidgetclock();
      


        $("#widgetfour").css('left', '-500px');
        $("#widgetclosemenu").css('left', '-500px');
        $('#iframe').css("left", '0px');
        $("#widgetthree").css('left', '-500px');
        $("#widgetsmenu").css('left', '-500px');
        $("#widgetone").css('left', '-500px');
        $("#widgettwo").css('left', '-500px');
   
  
        $("#nobg").css('left', '500px');
        $("#closemenu").css('left', '500px');
        $(".movewidgettext").css('left', '40px');
        $('#widget1').css("display", 'block');
        $.cookie('widget2', $("#widget2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget1', $("#widget1").css('display'),{ expires: 365,  path:'/'});
        $.cookie('closewidget', $("#closewidget").css('left'),{ expires: 365,  path:'/'});

    });



    if ($.cookie('widget2') != null) {
        $('#widget2').css('display', $.cookie('widget2'),{ expires: 365,  path:'/'});



    } else {
        $('#widget2').css('display', 'none');
    }


    if ($.cookie('widget1') != null) {
        $('#widget1').css('display', $.cookie('widget1'),{ expires: 365,  path:'/'});
createwidgetclock();

    } else {
        $('#widget1').css('display', 'none');
    }

    if ($.cookie('closewidget') != null) {
        $('#closewidget').css('left', $.cookie('closewidget'),{ expires: 365,  path:'/'});


    } else {
        $('#closewidget').css('left', '-500px');
    }




    $("#widgettwo").click(function () {
  closemenu();
  closepanels();
  createwidgetforecast();
        $("#widgetfour").css('left', '-500px');
        $("#widgetclosemenu").css('left', '-500px');
        $(".movewidgettext").css('top', '280px');
        $("#widgetthree").css('left', '-500px');
        $('#iframetwo').css("left", '0px');
        $('#iframe').css("left", '500px');
        $("#widgetsmenu").css('left', '-2500px');
        $("#widgetone").css('left', '-500px');
        $("#widgettwo").css('left', '-500px');


        $("#nobg").css('left', '500px');
        $("#closemenu").css('left', '500px');
        $('#widget2').css("display", 'block');
        $('#widget2').css("left", '-13px');
        $.cookie('widget2', $("#widget2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget1', $("#widget1").css('display'),{ expires: 365,  path:'/'});
        $.cookie('closewidget', $("#closewidget").css('left'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('widget2') != null) {
        $('#widget2').css('display', $.cookie('widget2'),{ expires: 365,  path:'/'});


    } else {
        $('#widget2').css('display', 'none');
    }


    if ($.cookie('widget1') != null) {
        $('#widget1').css('display', $.cookie('widget1'),{ expires: 365,  path:'/'});


    } else {
        $('#widget1').css('display', 'none');
    }

    if ($.cookie('closewidget') != null) {
        $('#closewidget').css('left', $.cookie('closewidget'),{ expires: 365,  path:'/'});


    } else {
        $('#closewidget').css('left', '-500px');
    }


if ($.cookie('union') != null) {  //if cookie was saved create uniAW
    createuni();
} 


    $("#widgetthree").click(function () {
closepanels();
 createuni();
   var union = "on";
    var unioff = "dont";



    $.cookie('union', (union), {
        expires: 365
    });
$.cookie('unioff', (unioff), {
        expires: 365
    });        $("#widgetfour").css('left', '-500px');
        $("#widgetclosemenu").css('left', '-500px');
        $("#widgetsmenu").css('left', '-2500px');
        $("#widgetthree").css('left', '-500px');
        $("#widgetone").css('left', '-500px');
        $("#widgettwo").css('left', '-500px');
  
        

        $('#widget3').css("display", 'block');
        $.cookie('widget2', $("#widget2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget1', $("#widget1").css('display'),{ expires: 365,  path:'/'});
        $.cookie('closewidget', $("#closewidget").css('left'),{ expires: 365,  path:'/'});
        $.cookie('widget3', $("#widget3").css('display'),{ expires: 365,  path:'/'});
        $("#widgetthree").css('left', '-500px');


    });

    if ($.cookie('widget3') != null) {

        $('#widget3').css('display', $.cookie('widget3'),{ expires: 365,  path:'/'});


    } else {
        $('#widget3').css('display', 'none');
    }




    if ($.cookie('closewidget') != null) {
        $('#closewidget').css('left', $.cookie('closewidget'),{ expires: 365,  path:'/'});


    } else {
        $('#closewidget').css('left', '-500px');
    }



    $("#widgetfour").click(function () {
closepanels();
        $("#widgetclosemenu").css('left', '-500px');
        $("#widgetsmenu").css('left', '-500px');
        $("#widgetfour").css('left', '-500px');
        $("#widgetthree").css('left', '-500px');
        $('#iframefour').css("left", '0px');
        $("#widgetone").css('left', '-500px');
        $("#widgettwo").css('left', '-500px');

        $("#nobg").css('left', '500px');
        $("#closemenu").css('left', '500px');
        $('#widget4').css("display", 'block');
        $.cookie('widget2', $("#widget2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget1', $("#widget1").css('display'),{ expires: 365,  path:'/'});
        $.cookie('closewidget', $("#closewidget").css('left'),{ expires: 365,  path:'/'});
        $.cookie('widget3', $("#widget3").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget4', $("#widget4").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget4onoff', "on");

        $("#widgetthree").css('left', '-500px');


    });


    if ($.cookie('widget4onoff') != null) {
        var on = $.cookie('widget4onoff');



    } else {
        $.cookie('widget4on', ("off"));

    }

    if ($.cookie('widget4') != null) {
        $('#widget4').css('display', $.cookie('widget4'),{ expires: 365,  path:'/'});


    } else {
        $('#widget4').css('display', 'none');
    }




    if ($.cookie('closewidget') != null) {
        $('#closewidget').css('left', $.cookie('closewidget'),{ expires: 365,  path:'/'});


    } else {
        $('#closewidget').css('left', '-500px');
    }




function closepanels(){
   $("#settingspanel").css('left', '-1000px');
$("#settingsclose").css('left', '-1000px');


}



    $("#widgetclosemenu").click(function () {
        $("#themes").css('left', '-800px');
        $("#closewidgetclosemenu").css('left', '0px');
        $("#closewidgetclosemenu").css('opacity', '0.7');
        $("#widgetfour").css('left', '-500px');
        $("#widgetclosemenu").css('left', '-500px');
        $("#closewidget1").css('left', '0px');
        $("#closewidget1").css('opacity', '0.7');
        $("#closewidget2").css('left', '0px');
        $("#closewidget2").css('opacity', '0.7');
        $("#closewidget3").css('left', '0px');
        $("#closewidget3").css('opacity', '0.7');
        $("#closewidget4").css('left', '0px');
        $("#closewidget4").css('opacity', '0.7');
        $('#closewidget').css("left", '-500px');
        $("#widgetfour").css('left', '-500px');

        $.cookie('closewidget', $("#closewidget").css('left'),{ expires: 365,  path:'/'});
    
       
        $("#closemenu").css('left', '500px');
        $("#widgetsmenu").css('left', '-500px');

        $("#widgetthree").css('left', '-500px');
        $("#widgetone").css('left', '-500px');
        $("#widgettwo").css('left', '-500px');
        $(".settingspanelcolors").css('left', '500px');
        $(".fontcolors").css('left', '500px');
        $(".settingspanelfallingobjects").css('left', '-500px');
        $("#settingspanel").css('left', '-500px');
        $("#settingsclose").css('left', '-500px');


    });


    $("#closewidgetclosemenu").click(function () {

        $("#themes").css('left', '-800px');
        $("#widgetfour").css('left', '-500px');
        $("#closewidgetclosemenu").css('left', '-500px');

        $('#iframe').css("left", '500px');
        $("#widgetsmenu").css('left', '-500px');
        $("#widgetone").css('left', '-500px');
        $('#closewidget1').css("left", '-500px');
        $('#closewidget2').css("left", '-500px');
        $('#closewidget3').css("left", '-500px');
        $('#closewidget4').css("left", '-500px');
        $.cookie('widget2', $("#widget2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget1', $("#widget1").css('display'),{ expires: 365,  path:'/'});
        $.cookie('closewidget1', $("#closewidget1").css('left'),{ expires: 365,  path:'/'});
      
    
     
        $("#closemenu").css('left', '500px');
        $("#widgetsmenu").css('left', '-500px');
        $(".settingspanelcolors").css('left', '500px');
        $(".fontcolors").css('left', '500px');
        $(".settingspanelfallingobjects").css('left', '-500px');
        $("#settingspanel").css('left', '-500px');
        $("#settingsclose").css('left', '-500px');

    });


    $("#closewidget1").click(function () {

removewidgetclock()


        $("#widgetfour").css('left', '-500px');
        $('#closewidget4').css("left", '-500px');
        $("#widgetfour").css('left', '-500px');
        $("#closewidgetclosemenu").css('left', '-500px');
        $('#iframe').css("left", '500px');
        $("#widgetsmenu").css('left', '-500px');
        $("#widgetone").css('left', '-500px');
        $('#closewidget1').css("left", '-500px');
        $('#closewidget2').css("left", '-500px');
        $('#closewidget3').css("left", '-500px');
        $('#widget1').css("display", 'none');
        $.cookie('widget2', $("#widget2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget1', $("#widget1").css('display'),{ expires: 365,  path:'/'});
        $.cookie('closewidget1', $("#closewidget1").css('left'),{ expires: 365,  path:'/'});
    

   
        $("#closemenu").css('left', '500px');
        $("#widgetsmenu").css('left', '-500px');

    });

    $("#closewidget2").click(function () {
        removewidgetforecast();
        $('#closewidget4').css("left", '-500px');
        $("#widgetfour").css('left', '-500px');
        $("#closewidgetclosemenu").css('left', '-500px');
        $('#iframe').css("left", '500px');
        $("#widgetsmenu").css('left', '-500px');
        $("#widgettwo").css('left', '-500px');
        $('#widget2').css("display", 'none');
        $('#closewidget1').css("left", '-500px');
        $('#closewidget2').css("left", '-500px');
        $('#closewidget3').css("left", '-500px');
        $.cookie('widget2', $("#widget2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget1', $("#widget1").css('display'),{ expires: 365,  path:'/'});
        $.cookie('closewidget2', $("#closewidget2").css('left'),{ expires: 365,  path:'/'});
      
      
     
        $("#closemenu").css('left', '500px');
        $("#widgetsmenu").css('left', '-500px');

    });

    $("#closewidget3").click(function () {
               removeuni();
      var union = null;
        $('#closewidget4').css("left", '-500px');
        $("#widgetfour").css('left', '-500px');
        $("#closewidgetclosemenu").css('left', '-500px');
        $('#iframe').css("left", '500px');
        $("#widgetsmenu").css('left', '-500px');
        $("#widgetthree").css('left', '-500px');
        $('#widget3').css("display", 'none');
        $('#closewidget3').css("left", '-500px');
        $('#closewidget2').css("left", '-500px');
        $('#closewidget1').css("left", '-500px');
        $.cookie('widget2', $("#widget2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget3', $("#widget3").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget1', $("#widget1").css('display'),{ expires: 365,  path:'/'});
        $.cookie('closewidget3', $("#closewidget3").css('left'),{ expires: 365,  path:'/'});
    
        $("#closemenu").css('left', '500px');
        $("#widgetsmenu").css('left', '-500px');

    });

    $("#closewidget4").click(function () {
        $("#themes").css('left', '-800px');
        $('#closewidget4').css("left", '-500px');
        $("#widgetfour").css('left', '-500px');
        $("#closewidgetclosemenu").css('left', '-500px');
        $('#iframe').css("left", '500px');
        $("#widgetsmenu").css('left', '-500px');


        $('#widget4').css("display", 'none');
        $('#closewidget4').css("left", '-500px');
        $('#closewidget3').css("left", '-500px');
        $('#closewidget2').css("left", '-500px');
        $('#closewidget1').css("left", '-500px');
        $.cookie('widget2', $("#widget2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget4', $("#widget2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget3', $("#widget2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('widget1', $("#widget1").css('display'),{ expires: 365,  path:'/'});
        $.cookie('closewidget3', $("#closewidget3").css('left'),{ expires: 365,  path:'/'});
     
    
      
        $("#closemenu").css('left', '500px');
        $("#widgetsmenu").css('left', '-500px');
        $.cookie('widget4onoff', "off");

    });

    $("#closemenu").click(function () {
        $(".settingspanelcolors").css('left', '500px');
        $(".fontcolors").css('left', '500px');
        $("#themes").css('left', '-800px');
        $('#closewidget4').css("left", '-500px');
        $("#widgetfour").css('left', '-500px');

        $('#closewidget').css("left", '-500px');

        $.cookie('closewidget', $("#closewidget").css('left'),{ expires: 365,  path:'/'},{ expires: 365,  path:'/'});
     
    
        
        $("#closemenu").css('left', '500px');
        $("#widgetsmenu").css('left', '-500px');

        $("#widgetthree").css('left', '-500px');
        $("#widgetone").css('left', '-500px');
        $("#widgettwo").css('left', '-500px');
        $("#widgetclosemenu").css('left', '-500px');
        $(".settingspanelfallingobjects").css('left', '-500px');
        $("#settingspanel").css('left', '-500px');
        $("#settingsclose").css('left', '-500px');

    });

    if ($.cookie('widget2') != null) {
        $('#widget2').css('display', $.cookie('widget2'),{ expires: 365,  path:'/'});
createwidgetforecast();

    } else {
        $('#widget2').css('display', 'none');
    }


    if ($.cookie('widget1') != null) {
        $('#widget1').css('display', $.cookie('widget1'),{ expires: 365,  path:'/'});


    } else {
        $('#widget1').css('display', 'none');
    }


    if ($.cookie('closewidget') != null) {
        $('#closewidget').css('left', $.cookie('closewidget'),{ expires: 365,  path:'/'});



    } else {
        $('#closewidget').css('left', '-500');
    }

    $("#calendar").draggable({
         containment: "#container6",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('calleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('calright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('calleft') != null) {
        $('#calendar').css('left', $.cookie('calleft'),{ expires: 365,  path:'/'});
    } else {
        $('#calendar').css('left', '0px');
    }
    if ($.cookie('calright') != null) {
        $('#calendar').css('top', $.cookie('calright'),{ expires: 365,  path:'/'});
    } else {
        $('#calendar').css('top', '0px');
    }




    //------------------------------------------------Make iframes Draggable---------------------------------

    $(function () {
        $("#iframe").draggable();

        $("#iframe").bind("drag", function (event, ui) {
            var div = $("#widget1");
            div.text("Top: " + div.css("top") + ", Left: " + div.css("left"));
            div.css({
                top: ui.offset.top,
                left: ui.offset.left
            });
            $.cookie('widget1left', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('widget1right', $(this).css('top'),{ expires: 365,  path:'/'});
        });
    });

    if ($.cookie('widget1left') != null) {
        $('#widget1').css('left', $.cookie('widget1left'),{ expires: 365,  path:'/'});
    } else {
        $('#widget1').css('left', '0px');
    }
    if ($.cookie('widget1right') != null) {
        $('#widget1').css('top', $.cookie('widget1right'),{ expires: 365,  path:'/'});
    } else {
        $('#widget1').css('top', '0px');
    }


    $(function () {
        $("#iframetwo").draggable();
        $("#iframetwo").bind("drag", function (event, ui) {
            var div = $("#widget2");
            div.text("Top: " + div.css("top") + ", Left: " + div.css("left"));
            div.css({
                top: ui.offset.top,
                left: ui.offset.left
            });
            $.cookie('widget2left', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('widget2right', $(this).css('top'),{ expires: 365,  path:'/'});
        });
    });


    if ($.cookie('widget2left') != null) {
        $('#widget2').css('left', $.cookie('widget2left'),{ expires: 365,  path:'/'});
    } else {
        $('#widget2').css('left', '0px');
    }
    if ($.cookie('widget2right') != null) {
        $('#widget2').css('top', $.cookie('widget2right'),{ expires: 365,  path:'/'});
    } else {
        $('#widget2').css('top', '0px');
    }


    $(function () {
        $("#iframefour").draggable();
        $("#iframefour").bind("drag", function (event, ui) {
            var div = $("#widget4");
            div.text("Top: " + div.css("top") + ", Left: " + div.css("left"));
            div.css({
                top: ui.offset.top,
                left: ui.offset.left
            });
            $.cookie('widget4left', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('widget4right', $(this).css('top'),{ expires: 365,  path:'/'});
        });
    });


    if ($.cookie('widget4left') != null) {
        $('#widget4').css('left', $.cookie('widget4left'),{ expires: 365,  path:'/'});
    } else {
        $('#widget4').css('left', '0px');
    }
    if ($.cookie('widget4right') != null) {
        $('#widget4').css('top', $.cookie('widget4right'),{ expires: 365,  path:'/'});
    } else {
        $('#widget4').css('top', '0px');
    }
    //------------------------------------------------End iframe Drag---------------------------------

    //------------------------------------------------Begin element choices---------------------------------


    $("#description").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('descriptionleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('descriptionright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('descriptionleft') != null) {
        $('#description').css('left', $.cookie('descriptionleft'),{ expires: 365,  path:'/'});
    } else {
        $('#description').css('left', '0px');
    }
    if ($.cookie('descriptionright') != null) {
        $('#description').css('top', $.cookie('descriptionright'),{ expires: 365,  path:'/'});
    } else {
        $('#description').css('top', '0px');
    }




    $("#Tweetbot").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('Tweetbotleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('Tweetbotright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('Tweetbotleft') != null) {
        $('#Tweetbot').css('left', $.cookie('Tweetbotleft'),{ expires: 365,  path:'/'});
    } else {
        $('#Tweetbot').css('left', '-800px');
    }
    if ($.cookie('Tweetbotright') != null) {
        $('#Tweetbot').css('top', $.cookie('Tweetbotright'),{ expires: 365,  path:'/'});
    } else {
        $('#Tweetbot').css('top', '0px');
    }




    $("#Phone").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('Phoneleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('Phoneright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('Phoneleft') != null) {
        $('#Phone').css('left', $.cookie('Phoneleft'),{ expires: 365,  path:'/'});
    } else {
        $('#Phone').css('left', '-800px');
    }
    if ($.cookie('Phoneright') != null) {
        $('#Phone').css('top', $.cookie('Phoneright'),{ expires: 365,  path:'/'});
    } else {
        $('#Phone').css('top', '0px');
    }




    $("#Mail").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('Mailleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('Mailright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('Mailleft') != null) {
        $('#Mail').css('left', $.cookie('Mailleft'),{ expires: 365,  path:'/'});
    } else {
        $('#Mail').css('left', '-800px');
    }
    if ($.cookie('Mailright') != null) {
        $('#Mail').css('top', $.cookie('Mailright'),{ expires: 365,  path:'/'});
    } else {
        $('#Mail').css('top', '0px');
    }




    $("#Facebook").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('Facebookleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('Facebookright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('Facebookleft') != null) {
        $('#Facebook').css('left', $.cookie('Facebookleft'),{ expires: 365,  path:'/'});
    } else {
        $('#Facebook').css('left', '-800px');
    }
    if ($.cookie('Facebookright') != null) {
        $('#Facebook').css('top', $.cookie('Facebookright'),{ expires: 365,  path:'/'});
    } else {
        $('#Facebook').css('top', '0px');
    }



    $("#Timer").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('Timerleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('Timerright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('Timerleft') != null) {
        $('#Timer').css('left', $.cookie('Timerleft'),{ expires: 365,  path:'/'});
    } else {
        $('#Timer').css('left', '-800px');
    }
    if ($.cookie('Timerright') != null) {
        $('#Timer').css('top', $.cookie('Timerright'),{ expires: 365,  path:'/'});
    } else {
        $('#Timer').css('top', '0px');
    }



    $("#Messages").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('Messagesleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('Messagesright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('Messagesleft') != null) {
        $('#Messages').css('left', $.cookie('Messagesleft'),{ expires: 365,  path:'/'});
    } else {
        $('#Messages').css('left', '-800px');
    }
    if ($.cookie('Messagesright') != null) {
        $('#Messages').css('top', $.cookie('Messagesright'),{ expires: 365,  path:'/'});
    } else {
        $('#Messages').css('top', '0px');
    }



    $("#Instagram").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('Instagramleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('Instagramright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('Instagramleft') != null) {
        $('#Instagram').css('left', $.cookie('Instagramleft'),{ expires: 365,  path:'/'});
    } else {
        $('#Instagram').css('left', '-800px');
    }
    if ($.cookie('Instagramright') != null) {
        $('#Instagram').css('top', $.cookie('Instagramright'),{ expires: 365,  path:'/'});
    } else {
        $('#Instagram').css('top', '0px');
    }

    

    $("#Line").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('Lineleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('Lineright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('Lineleft') != null) {
        $('#Line').css('left', $.cookie('Lineleft'),{ expires: 365,  path:'/'});
    } else {
        $('#Line').css('left', '-800px');
    }
    if ($.cookie('Lineright') != null) {
        $('#Line').css('top', $.cookie('Lineright'),{ expires: 365,  path:'/'});
    } else {
        $('#Line').css('top', '0px');
    }

    $("#humid").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('humidleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('humidright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('humidleft') != null) {
        $('#humid').css('left', $.cookie('humidleft'),{ expires: 365,  path:'/'});
    } else {
        $('#humid').css('left', '0px');
    }
    if ($.cookie('humidright') != null) {
        $('#humid').css('top', $.cookie('humidright'),{ expires: 365,  path:'/'});
    } else {
        $('#humid').css('top', '0px');
    }

    $("#low").draggable({
         containment: "#container3",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('lowleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('lowright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('lowleft') != null) {
        $('#low').css('left', $.cookie('lowleft'),{ expires: 365,  path:'/'});
    } else {
        $('#low').css('left', '0px');
    }
    if ($.cookie('lowright') != null) {
        $('#low').css('top', $.cookie('lowright'),{ expires: 365,  path:'/'});
    } else {
        $('#low').css('top', '0px');
    }

    $("#high").draggable({
         containment: "#container3",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('highleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('highright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('highleft') != null) {
        $('#high').css('left', $.cookie('highleft'),{ expires: 365,  path:'/'});
    } else {
        $('#high').css('left', '0px');
    }
    if ($.cookie('highright') != null) {
        $('#high').css('top', $.cookie('highright'),{ expires: 365,  path:'/'});
    } else {
        $('#high').css('top', '0px');
    }

    $("#degrees").draggable({
        containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('degreesleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('degreesright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('degreesleft') != null) {
        $('#degrees').css('left', $.cookie('degreesleft'),{ expires: 365,  path:'/'});
    } else {
        $('#degrees').css('left', '0px');
    }
    if ($.cookie('degreesright') != null) {
        $('#degrees').css('top', $.cookie('degreesright'),{ expires: 365,  path:'/'});
    } else {
        $('#degrees').css('top', '0px');
    }

    $("#iconoff").click(function () {
        $('#weatherIcon2').css("display", 'block');
        $.cookie('iconstate', $("#weatherIcon2").css('display'),{ expires: 365,  path:'/'});

    });

    $("#yourcity").draggable({
        containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('yourcityleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('yourcityright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('yourcityleft') != null) {
        $('#yourcity').css('left', $.cookie('yourcityleft'),{ expires: 365,  path:'/'});
    } else {
        $('#yourcity').css('left', '0px');
    }
    if ($.cookie('yourcityright') != null) {
        $('#yourcity').css('top', $.cookie('yourcityright'),{ expires: 365,  path:'/'});
    } else {
        $('#yourcity').css('top', '0px');
    }





    //------------------------------------------------Start fonts--------------------------------





    $("#setfont1").click(function () {
        $("#setfont1").css('color', 'blue');
        $("#setfont2").css('color', '');
        $("#setfont3").css('color', '');
        $("#setfont4").css('color', '');
        $("#setfont5").css('color', '');
        $("#setfont6").css('color', '');
        $("#setfont7").css('color', '');
        $("#setfont8").css('color', '');


        $('#TextContainer').css("font-family", 'BU');
        $.cookie('fontstate', $("#TextContainer").css('font-family'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('fontstate') != null) {
        $('#TextContainer').css('font-family', $.cookie('fontstate'),{ expires: 365,  path:'/'});


    } else {
        $('#fontstate').css('font-family', 'BU');
    }



    $("#setfont2").click(function () {

        $("#setfont1").css('color', '');
        $("#setfont2").css('color', 'blue');
        $("#setfont3").css('color', '');
        $("#setfont4").css('color', '');
        $("#setfont5").css('color', '');
        $("#setfont6").css('color', '');
        $("#setfont7").css('color', '');
        $("#setfont8").css('color', '');

        $('#TextContainer').css("font-family", 'CA');
        $.cookie('fontstate', $("#TextContainer").css('font-family'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('fontstate') != null) {
        $('#TextContainer').css('font-family', $.cookie('fontstate'),{ expires: 365,  path:'/'});


    } else {
        $('#fontstate').css('font-family', 'CA');
    }


    $("#setfont3").click(function () {
        $("#setfont1").css('color', '');
        $("#setfont2").css('color', '');
        $("#setfont3").css('color', 'blue');
        $("#setfont4").css('color', '');
        $("#setfont5").css('color', '');
        $("#setfont6").css('color', '');
        $("#setfont7").css('color', '');
        $("#setfont8").css('color', '');


        $('#TextContainer').css("font-family", 'JT');
        $.cookie('fontstate', $("#TextContainer").css('font-family'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('fontstate') != null) {
        $('#TextContainer').css('font-family', $.cookie('fontstate'),{ expires: 365,  path:'/'});


    } else {
        $('#fontstate').css('font-family', 'JT');
    }

    $("#setfont4").click(function () {

        $("#setfont1").css('color', '');
        $("#setfont2").css('color', '');
        $("#setfont3").css('color', '');
        $("#setfont4").css('color', 'blue');
        $("#setfont5").css('color', '');
        $("#setfont6").css('color', '');
        $("#setfont7").css('color', '');
        $("#setfont8").css('color', '');

        $('#TextContainer').css("font-family", 'TD');
        $.cookie('fontstate', $("#TextContainer").css('font-family'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('fontstate') != null) {
        $('#TextContainer').css('font-family', $.cookie('fontstate'),{ expires: 365,  path:'/'});


    } else {
        $('#fontstate').css('font-family', 'TD');
    }

    $("#setfont5").click(function () {

        $("#setfont1").css('color', '');
        $("#setfont2").css('color', '');
        $("#setfont3").css('color', '');
        $("#setfont4").css('color', '');
        $("#setfont5").css('color', 'blue');
        $("#setfont6").css('color', '');
        $("#setfont7").css('color', '');
        $("#setfont8").css('color', '');

        $('#TextContainer').css("font-family", 'BG');
        $.cookie('fontstate', $("#TextContainer").css('font-family'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('fontstate') != null) {
        $('#TextContainer').css('font-family', $.cookie('fontstate'),{ expires: 365,  path:'/'});


    } else {
        $('#fontstate').css('font-family', 'BG');
    }

    $("#setfont6").click(function () {

        $("#setfont1").css('color', '');
        $("#setfont2").css('color', '');
        $("#setfont3").css('color', '');
        $("#setfont4").css('color', '');
        $("#setfont5").css('color', '');
        $("#setfont6").css('color', 'blue');
        $("#setfont7").css('color', '');
        $("#setfont8").css('color', '');

        $('#TextContainer').css("font-family", 'WG');
        $.cookie('fontstate', $("#TextContainer").css('font-family'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('fontstate') != null) {
        $('#TextContainer').css('font-family', $.cookie('fontstate'),{ expires: 365,  path:'/'});


    } else {
        $('#fontstate').css('font-family', 'WG');
    }

    $("#setfont7").click(function () {

        $("#setfont1").css('color', '');
        $("#setfont2").css('color', '');
        $("#setfont3").css('color', '');
        $("#setfont4").css('color', '');
        $("#setfont5").css('color', '');
        $("#setfont6").css('color', '');
        $("#setfont7").css('color', 'blue');
        $("#setfont8").css('color', '');

        $('#TextContainer').css("font-family", 'SM');
        $.cookie('fontstate', $("#TextContainer").css('font-family'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('fontstate') != null) {
        $('#TextContainer').css('font-family', $.cookie('fontstate'),{ expires: 365,  path:'/'});


    } else {
        $('#fontstate').css('font-family', "SM");
    }

    $("#setfont8").click(function () {

        $("#setfont1").css('color', '');
        $("#setfont2").css('color', '');
        $("#setfont3").css('color', '');
        $("#setfont4").css('color', '');
        $("#setfont5").css('color', '');
        $("#setfont6").css('color', '');
        $("#setfont7").css('color', '');
        $("#setfont8").css('color', 'blue');

        $('#TextContainer').css("font-family", 'NE');
        $.cookie('fontstate', $("#TextContainer").css('font-family'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('fontstate') != null) {
        $('#TextContainer').css('font-family', $.cookie('fontstate'),{ expires: 365,  path:'/'});


    } else {
        $('#fontstate').css('font-family', 'NE');
    }




    //------------------------------------------------Font colors--------------------------------





    $("#color1").click(function () {


        $('#TextContainer').css("color", 'blue');
        $.cookie('colorstate', $("#TextContainer").css('color'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('colorstate') != null) {
        $('#TextContainer').css('color', $.cookie('colorstate'),{ expires: 365,  path:'/'});


    } else {
        $('#colorstate').css('color', 'red');
    }



    $("#color2").click(function () {



        $('#TextContainer').css("color", 'red');
        $.cookie('colorstate', $("#TextContainer").css('color'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('colorstate') != null) {
        $('#TextContainer').css('color', $.cookie('colorstate'),{ expires: 365,  path:'/'});


    } else {
        $('#colorstate').css('color', 'green');
    }


    $("#color3").click(function () {



        $('#TextContainer').css("color", 'purple');
        $.cookie('colorstate', $("#TextContainer").css('color'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('colorstate') != null) {
        $('#TextContainer').css('color', $.cookie('colorstate'),{ expires: 365,  path:'/'});


    } else {
        $('#colorstate').css('color', 'white');
    }

    $("#color4").click(function () {



        $('#TextContainer').css("color", 'green');
        $.cookie('colorstate', $("#TextContainer").css('color'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('colorstate') != null) {
        $('#TextContainer').css('color', $.cookie('colorstate'),{ expires: 365,  path:'/'});


    } else {
        $('#colorstate').css('color', 'white');
    }

    $("#color5").click(function () {



        $('#TextContainer').css("color", 'pink');
        $.cookie('colorstate', $("#TextContainer").css('color'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('colorstate') != null) {
        $('#TextContainer').css('color', $.cookie('colorstate'),{ expires: 365,  path:'/'});


    } else {
        $('#colorstate').css('color', 'white');
    }

    $("#color6").click(function () {



        $('#TextContainer').css("color", 'white');
        $.cookie('colorstate', $("#TextContainer").css('color'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('colorstate') != null) {
        $('#TextContainer').css('color', $.cookie('colorstate'),{ expires: 365,  path:'/'});


    } else {
        $('#colorstate').css('color', 'white');
    }

    $("#color7").click(function () {



        $('#TextContainer').css("color", 'black');
        $.cookie('colorstate', $("#TextContainer").css('color'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('colorstate') != null) {
        $('#TextContainer').css('color', $.cookie('colorstate'),{ expires: 365,  path:'/'});


    } else {
        $('#colorstate').css('color', "white");
    }

    $("#color8").click(function () {



        $('#TextContainer').css("color", 'orange');
        $.cookie('colorstate', $("#TextContainer").css('color'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('colorstate') != null) {
        $('#TextContainer').css('color', $.cookie('colorstate'),{ expires: 365,  path:'/'});


    } else {
        $('#colorstate').css('color', 'white');
    }




    //------------------------------------------------Start press buttons--------------------------------






    $("#tempon").click(function () {
        $('#tempon').css("left", '160px');
        $('#tempoff').css("left", '120px');
        $('#temp').css("display", 'none');
        $.cookie('tempstate', $("#temp").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#tempoff").css('left'),{ expires: 365,  path:'/'});
    });

    if ($.cookie('tempstate') != null) {
        $('#temp').css('display', $.cookie('tempstate'),{ expires: 365,  path:'/'});


    } else {
        $('#tempstate').css('display', 'none');
    }



    $("#tempoff").click(function () {
        $('#tempoff').css("left", '115px');
        $('#temp').css("display", 'block');
        $.cookie('tempstate', $("#temp").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#tempoff").css('left'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('buttoncook') != null) {
        $('#tempoff').css('left', $.cookie('buttoncook'),{ expires: 365,  path:'/'});


    } else {
        $('#tempoff').css('left', 'buttoncook');
    }



    //------------------------------------------------icon-------------------------------



    $("#iconoff").click(function () {
        $('#iconon').css("left", '160px');
        $('#iconoff').css("left", '120px');
        $('#iconoff').css("left", '115px');
        $('#weatherIcon2').css("display", 'block');
        $.cookie('iconstate', $("#weatherIcon2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#iconoff").css('left'),{ expires: 365,  path:'/'});

    });




    $("#iconon").click(function () {

        $('#iconon').css("left", '160px');
        $('#iconoff').css("left", '120px');
        $('#weatherIcon2').css("display", 'none');
        $.cookie('iconstate', $("#weatherIcon2").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#iconoff").css('left'),{ expires: 365,  path:'/'});
    });

    if ($.cookie('iconstate') != null) {
        $('#weatherIcon2').css('display', $.cookie('iconstate'),{ expires: 365,  path:'/'});


    } else {
        $('#iconstate').css('display', 'none');
    }

    if ($.cookie('buttoncook') != null) {
        $('#iconoff').css('left', $.cookie('buttoncook'),{ expires: 365,  path:'/'});


    } else {
        $('#iconoff').css('left', 'buttoncook');
    }




    //------------------------------------------------city-------------------------------



    $("#cityon").click(function () {

        $('#cityoff').css("left", '120px');
        $('#cityon').css("left", '160px');

        $('#city').css("display", 'none');
        $.cookie('citystate', $("#city").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#cityoff").css('left'),{ expires: 365,  path:'/'});
    });

    if ($.cookie('citystate') != null) {
        $('#city').css('display', $.cookie('citystate'),{ expires: 365,  path:'/'});


    } else {
        $('#citystate').css('display', 'none');
    }


    $("#cityoff").click(function () {
        $('#cityoff').css("left", '115px');
        $('#cityon').css("left", '160px');

        $('#city').css("display", 'block');
        $.cookie('citystate', $("#city").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#cityoff").css('left'),{ expires: 365,  path:'/'});
    });


    if ($.cookie('buttoncook') != null) {
        $('#cityoff').css('left', $.cookie('buttoncook'),{ expires: 365,  path:'/'});


    } else {
        $('#cityoff').css('left', 'buttoncook');
    }


    //------------------------------------------------humid-------------------------------





    $("#humidon").click(function () {
        $('#humidoff').css("left", '120px');
        $('#humidon').css("left", '160px');
        $('#humidity').css("display", 'none');
        $.cookie('humidstate', $("#humidity").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#humidoff").css('left'),{ expires: 365,  path:'/'});
    });

    if ($.cookie('humidstate') != null) {
        $('#humidity').css('display', $.cookie('humidstate'),{ expires: 365,  path:'/'});


    } else {
        $('#humidstate').css('display', 'none');
    }


    $("#humidoff").click(function () {
        $('#humidoff').css("left", '115px');
        $('#humidon').css("left", '160px');
        $('#humidity').css("display", 'block');
        $.cookie('humidstate', $("#humidity").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#humidoff").css('left'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('buttoncook') != null) {
        $('#humidoff').css('left', $.cookie('buttoncook'),{ expires: 365,  path:'/'});


    } else {
        $('#humidoff').css('left', 'buttoncook');
    }




    //------------------------------------------------desc-------------------------------







    $("#descon").click(function () {
        $('#descoff').css("left", '120px');
        $('#descon').css("left", '160px');
        $('#desc').css("display", 'none');
        $.cookie('descstate', $("#desc").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#descoff").css('left'),{ expires: 365,  path:'/'});
    });

    if ($.cookie('descstate') != null) {
        $('#desc').css('display', $.cookie('descstate'),{ expires: 365,  path:'/'});


    } else {
        $('#descstate').css('display', 'none');
    }


    $("#descoff").click(function () {
        $('#descoff').css("left", '115px');
        $('#descon').css("left", '160px');
        $('#desc').css("display", 'block');
        $.cookie('descstate', $("#desc").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#descoff").css('left'),{ expires: 365,  path:'/'});
    });

    if ($.cookie('buttoncook') != null) {
        $('#descoff').css('left', $.cookie('buttoncook'),{ expires: 365,  path:'/'});


    } else {
        $('#descoff').css('left', 'buttoncook');
    }



    //------------------------------------------------city-------------------------------



    $("#dateon").click(function () {

        $('#date').css("visibility", 'hidden');

        $('#dateoff').css("left", '120px');
        $('#dateon').css("left", '160px');


        $.cookie('datestate', $("#calendar").css('visibility'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#dateoff").css('left'),{ expires: 365,  path:'/'});
    });

    if ($.cookie('datestate') != null) {
        $('#date').css('visibility', $.cookie('datestate'),{ expires: 365,  path:'/'});



    } else {
        $('#datestate').css('visibility', 'hidden');
    }

    $("#dateoff").click(function () {
        $('#date').css("visibility", 'visible');

        $('#dateoff').css("left", '115px');
        $('#dateon').css("left", '160px');



        $.cookie('datestate', $("#date").css('visibility'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#dateoff").css('left'),{ expires: 365,  path:'/'});

    });

    if ($.cookie('buttoncook') != null) {
        $('#dateoff').css('left', $.cookie('buttoncook'),{ expires: 365,  path:'/'});
        $('#date').css('visibility', $.cookie('datestate'),{ expires: 365,  path:'/'});



    } else {
        $('#dateoff').css('visibility', 'visible');
    }


    //------------------------------------------------lo------------------------------



    $("#lowoff").click(function () {
        $('#lowoff').css("left", '115px');
        $('#lowon').css("left", '160px');
        $('#lo').css("display", 'block');
        $.cookie('lowstate', $("#low").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#lowoff").css('left'),{ expires: 365,  path:'/'});
    });

    $("#lowon").click(function () {
        $('#lowoff').css("left", '120px');
        $('#lowon').css("left", '160px');
        $('#lo').css("display", 'none');
        $.cookie('lowstate', $("#lo").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#lowoff").css('left'),{ expires: 365,  path:'/'});
    });

    if ($.cookie('lowstate') != null) {
        $('#lo').css('display', $.cookie('lowstate'),{ expires: 365,  path:'/'});


    } else {
        $('#lowstate').css('display', 'none');
    }

    if ($.cookie('buttoncook') != null) {
        $('#lowoff').css('left', $.cookie('buttoncook'),{ expires: 365,  path:'/'});


    } else {
        $('#lowoff').css('left', 'buttoncook');
    }



    //-----------------------------------------------high---------------------------





    $("#highoff").click(function () {
        $('#highoff').css("left", '115px');
        $('#highon').css("left", '160px');
        $('#hi').css("display", 'block');
        $.cookie('highstate', $("#hi").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#highoff").css('left'),{ expires: 365,  path:'/'});
    });

    $("#highon").click(function () {
        $('#highoff').css("left", '120px');
        $('#highon').css("left", '160px');
        $('#hi').css("display", 'none');
        $.cookie('highstate', $("#hi").css('display'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#highoff").css('left'),{ expires: 365,  path:'/'});
    });

    if ($.cookie('highstate') != null) {
        $('#hi').css('display', $.cookie('highstate'),{ expires: 365,  path:'/'});


    } else {
        $('#highstate').css('display', 'none');
    }


    if ($.cookie('buttoncook') != null) {
        $('#highoff').css('left', $.cookie('buttoncook'),{ expires: 365,  path:'/'});


    } else {
        $('#highoff').css('left', 'buttoncook');
    }




    //-----------------------------------------------Time---------------------------





    $("#timeoff").click(function () {

        $('#timeoff').css("left", '115px');
        $('#timeon').css("left", '160px');
        $('#Time').css("left", '150px');
        $('#clock').css("left", '100px');
        $.cookie('timestate', $("#Time").css('left'),{ expires: 365,  path:'/'});
        $.cookie('timestate', $("#clock").css('left'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#timeoff").css('left'),{ expires: 365,  path:'/'});
    });

    $("#timeon").click(function () {
        $('#timeoff').css("left", '120px');
        $('#timeon').css("left", '160px');
        $('#Time').css("left", '800px');
        $.cookie('timestate', $("#Time").css('left'),{ expires: 365,  path:'/'});
        $.cookie('#clock', $("#Time").css('left'),{ expires: 365,  path:'/'});
        $.cookie('buttoncook', $("#timeoff").css('left'),{ expires: 365,  path:'/'});
    });

    if ($.cookie('timestate') != null) {
        $('#Time').css('left', $.cookie('timestate'),{ expires: 365,  path:'/'});
        $('#clock').css('left', $.cookie('timestate'),{ expires: 365,  path:'/'});

    } else {
        $('#timetate').css('left', '0px');
        $('#clock').css('left', '500px');
    }


    if ($.cookie('buttoncook') != null) {
        $('#timeoff').css('left', $.cookie('buttoncook'),{ expires: 365,  path:'/'});


    } else {
        $('#timeoff').css('left', 'buttoncook');
    }


    //------------------------------------------------city-------------------------------

    $("#Time").draggable({
        containment: "#container4",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('timeleft', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('timeright', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('timeleft') != null) {
        $('#Time').css('left', $.cookie('timeleft'),{ expires: 365,  path:'/'});
    } else {
        $('#Time').css('left', '0px');
    }
    if ($.cookie('timeright') != null) {
        $('#Time').css('top', $.cookie('timeright'),{ expires: 365,  path:'/'});
    } else {
        $('#Time').css('top', '0px');
    }




    $("#weatherIcon2").draggable({
        containment: "#container5",
          scroll: false,
        stop: function (event, ui) {
            $.cookie('weatherIcon2left', $(this).css('left'),{ expires: 365,  path:'/'});
            $.cookie('weatherIcon2right', $(this).css('top'),{ expires: 365,  path:'/'});
        }
    });

    if ($.cookie('weatherIcon2left') != null) {
        $('#weatherIcon2').css('left', $.cookie('weatherIcon2left'),{ expires: 365,  path:'/'});
    } else {
        $('#weatherIcon2').css('left', '0px');
    }
    if ($.cookie('weatherIcon2right') != null) {
        $('#weatherIcon2').css('top', $.cookie('weatherIcon2right'),{ expires: 365,  path:'/'});
    } else {
        $('#weatherIcon2').css('top', '0px');
    }
});