

 //dropshadow





 b = "0";
$("#size1").click(function() {
b++

  $('#Tweetbot').css("left", '0px');
 $.cookie('Tweetbotleft', $("#Tweetbot").css('left'),{ expires: 365,  path:'/'}); 
    
$.cookie('tweetbot', $("#Tweetbot").css('left'),{ expires: 365,  path:'/'}); 
  if(b =="2"){

    value = null;

      $('#Tweetbot').css("left", '-400px');
      $.cookie('tweetbot', $("#Tweetbot").css('left'),{ expires: 365,  path:'/'}); 
     $.cookie('tweetbot', $("#Tweetbot").css('left'),{ expires: 365,  path:'/'}); 
    $.cookie('Tweetbotleft', $("#Tweetbot").css('left'),{ expires: 365,  path:'/'}); 
    
  }   

});

if($.cookie('tweetbot') != null){

    $('#Tweetbot').css('left', $.cookie('tweetbot'),{ expires: 365,  path:'/'});


}else{
    $('#Tweetbot').css('left', '0px');
 
}

if($.cookie('tweetbot') != null){
    $('#Tweetbot').css('left', $.cookie('tweetbot'),{ expires: 365,  path:'/'});


}else{
    $('#Tweetbot').css('left', '0px');
 
}




c = "0";
$("#size2").click(function() {
c++

  $('#Phone').css("left", '0px');
 $.cookie('Phoneleft', $("#Phone").css('left'),{ expires: 365,  path:'/'}); 
    
$.cookie('Phone', $("#Phone").css('left'),{ expires: 365,  path:'/'}); 
  if(c =="2"){

    value = null;

      $('#Phone').css("left", '-400px');
      $.cookie('Phone', $("#Phone").css('left'),{ expires: 365,  path:'/'}); 
     $.cookie('Phone', $("#Phone").css('left'),{ expires: 365,  path:'/'}); 
    $.cookie('Phoneleft', $("#Phone").css('left'),{ expires: 365,  path:'/'}); 
    
  }   

});

if($.cookie('Phone') != null){
 
    $('#Phone').css('left', $.cookie('Phone'),{ expires: 365,  path:'/'});


}else{
    $('#Phone').css('left', '0px');
 
}

if($.cookie('Phone') != null){
    $('#Phone').css('left', $.cookie('Phone'),{ expires: 365,  path:'/'});


}else{
    $('#Phone').css('left', '0px');
 
}


d = "0";
$("#size3").click(function() {
d++

  $('#Mail').css("left", '0px');
 $.cookie('Mailleft', $("#Mail").css('left'),{ expires: 365,  path:'/'}); 
    
$.cookie('Mail', $("#Mail").css('left'),{ expires: 365,  path:'/'}); 
  if(d =="2"){

    value = null;

      $('#Mail').css("left", '-400px');
      $.cookie('Mail', $("#Mail").css('left'),{ expires: 365,  path:'/'}); 
     $.cookie('Mail', $("#Mail").css('left'),{ expires: 365,  path:'/'}); 
    $.cookie('Mailleft', $("#Mail").css('left'),{ expires: 365,  path:'/'}); 
    
  }   

});

if($.cookie('Mail') != null){
  
    $('#Mail').css('left', $.cookie('Mail'),{ expires: 365,  path:'/'});


}else{
    $('#Mail').css('left', '0px');
 
}

if($.cookie('Mail') != null){
    $('#Mail').css('left', $.cookie('Mail'),{ expires: 365,  path:'/'});


}else{
    $('#Mail').css('left', '0px');
 
}
e = "0";
$("#size4").click(function() {
e++

  $('#Facebook').css("left", '0px');
 $.cookie('Facebookleft', $("#Facebook").css('left'),{ expires: 365,  path:'/'}); 
    
$.cookie('Facebook', $("#Facebook").css('left'),{ expires: 365,  path:'/'}); 
  if(e =="2"){

    value = null;

      $('#Facebook').css("left", '-400px');
      $.cookie('Facebook', $("#Facebook").css('left'),{ expires: 365,  path:'/'}); 
     $.cookie('Facebook', $("#Facebook").css('left'),{ expires: 365,  path:'/'}); 
    $.cookie('Facebookleft', $("#Facebook").css('left'),{ expires: 365,  path:'/'}); 
    
  }   

});

if($.cookie('Facebook') != null){
 
    $('#Facebook').css('left', $.cookie('Facebook'),{ expires: 365,  path:'/'});


}else{
    $('#Facebook').css('left', '0px');
 
}

if($.cookie('Facebook') != null){
    $('#Facebook').css('left', $.cookie('Facebook'),{ expires: 365,  path:'/'});


}else{
    $('#Facebook').css('left', '0px');
 
}

f = "0";
$("#size5").click(function() {
f++

  $('#Timer').css("left", '0px');
 $.cookie('Timerleft', $("#Timer").css('left'),{ expires: 365,  path:'/'}); 
    
$.cookie('Timer', $("#Timer").css('left'),{ expires: 365,  path:'/'}); 
  if(f =="2"){

    value = null;

      $('#Timer').css("left", '-400px');
      $.cookie('Timer', $("#Timer").css('left'),{ expires: 365,  path:'/'}); 
     $.cookie('Timer', $("#Timer").css('left'),{ expires: 365,  path:'/'}); 
    $.cookie('Timerleft', $("#Timer").css('left'),{ expires: 365,  path:'/'}); 
    
  }   

});

if($.cookie('Timer') != null){

    $('#Timer').css('left', $.cookie('Timer'),{ expires: 365,  path:'/'});


}else{
    $('#Timer').css('left', '0px');
 
}

if($.cookie('Timer') != null){
    $('#Timer').css('left', $.cookie('Timer'),{ expires: 365,  path:'/'});


}else{
    $('#Timer').css('left', '0px');
 
}


g = "0";
$("#size6").click(function() {
g++

  $('#Messages').css("left", '0px');
 $.cookie('Messagesleft', $("#Messages").css('left'),{ expires: 365,  path:'/'}); 
    
$.cookie('Messages', $("#Messages").css('left'),{ expires: 365,  path:'/'}); 
  if(g =="2"){

    value = null;

      $('#Messages').css("left", '-400px');
      $.cookie('Messages', $("#Messages").css('left'),{ expires: 365,  path:'/'}); 
     $.cookie('Messages', $("#Messages").css('left'),{ expires: 365,  path:'/'}); 
    $.cookie('Messagesleft', $("#Messages").css('left'),{ expires: 365,  path:'/'}); 
    
  }   

});

if($.cookie('Messages') != null){

    $('#Messages').css('left', $.cookie('Messages'),{ expires: 365,  path:'/'});


}else{
    $('#Messages').css('left', '0px');
 
}

if($.cookie('Messages') != null){
    $('#Messages').css('left', $.cookie('Messages'),{ expires: 365,  path:'/'});


}else{
    $('#Messages').css('left', '0px');
 
}



j = "0";
$("#size7").click(function() {
j++

  $('#Instagram').css("left", '0px');
 $.cookie('Instagramleft', $("#Instagram").css('left'),{ expires: 365,  path:'/'}); 
    
$.cookie('Instagram', $("#Instagram").css('left'),{ expires: 365,  path:'/'}); 
  if(j =="2"){

    value = null;

      $('#Instagram').css("left", '-400px');
      $.cookie('Instagram', $("#Instagram").css('left'),{ expires: 365,  path:'/'}); 
     $.cookie('Instagram', $("#Instagram").css('left'),{ expires: 365,  path:'/'}); 
    $.cookie('Instagramleft', $("#Instagram").css('left'),{ expires: 365,  path:'/'}); 
    
  }   

});

if($.cookie('Instagram') != null){

    $('#Instagram').css('left', $.cookie('Instagram'),{ expires: 365,  path:'/'});


}else{
    $('#Instagram').css('left', '0px');
 
}

if($.cookie('Instagram') != null){
    $('#Instagram').css('left', $.cookie('Instagram'),{ expires: 365,  path:'/'});


}else{
    $('#Instagram').css('left', '0px');
 
}
l = "0";
$("#size8").click(function() {
l++

  $('#Line').css("left", '0px');
 $.cookie('Lineleft', $("#Line").css('left'),{ expires: 365,  path:'/'}); 
    
$.cookie('Line', $("#Line").css('left'),{ expires: 365,  path:'/'}); 
  if(l =="2"){

    value = null;

      $('#Line').css("left", '-400px');
      $.cookie('Line', $("#Line").css('left'),{ expires: 365,  path:'/'}); 
     $.cookie('Line', $("#Line").css('left'),{ expires: 365,  path:'/'}); 
    $.cookie('Lineleft', $("#Line").css('left'),{ expires: 365,  path:'/'}); 
    
  }   

});

if($.cookie('Line') != null){

    $('#Line').css('left', $.cookie('Line'),{ expires: 365,  path:'/'});


}else{
    $('#Line').css('left', '0px');
 
}

if($.cookie('Line') != null){
    $('#Line').css('left', $.cookie('Line'),{ expires: 365,  path:'/'});


}else{
    $('#Line').css('left', '0px');
 
}

//speed things up a bit

 if (navigator.platform === 'iPad') {
}



//hack to hide icons and weatherIcon

//after document loads fix these items
$( document ).ready(function() {

setTimeout('unhideicons()', 1300);

setTimeout('unhideicons2()', 10);


if (navigator.platform === 'iPad') {
 $('meta[name=viewport]').attr('content','width=700, height=1000, initial-scale=2.4, maximum-scale=2.4, user-scalable=no');

$("#overlay").addClass("iPad");
 
}

  $('#clock').css('color', $.cookie('colorstate'),{ expires: 365,  path:'/'});

});
/////////////////////////////////////////////
function unhideicons(){
  $('.do').css('display', 'block');
    $('#Time').css('display', 'block');
      $(".do").css('marginTop', '0px');
     
}

function  unhideicons2(){
$('#opensettings').css('display', 'block');
$("weatherIcon").css('display', 'block');
}


//changing text for Background
var newText = "Weather will show the weather background. Locks allows you to enter a lockscreen name. Get this name from any lockscreen in winterboard. Press refresh to load to remove press locks and then cancel. Walls lets you visit a blog with walls posted. Take a screen shot of these then load via setBackground.cydget. Animated wallpaper click to show, click again to remove.";
document.getElementById("bgwall").innerText = newText;


//If iPad then change scaling


//var zIndex = $("#Tweetbot").css('z-index');
//var position = $("#Tweetbot").position();
//alert('X: ' + position.left + ", Y: " + position.top + " z-Index " +zIndex );


//Fix for icons. without this there off -500 to the top
$("#size1").click(function() {
$('#Tweetbot').css('top', '0px');
});
$("#size2").click(function() {
$('#Phone').css('top', '0px');
});
$("#size3").click(function() {
$('#Mail').css('top', '0px');
});
$("#size4").click(function() {
$('#Facebook').css('top', '0px');

});
$("#size5").click(function() {
$('#Timer').css('top', '0px');
});
$("#size6").click(function() {
$('#Messages').css('top', '0px');
});
$("#size7").click(function() {
$('#Instagram').css('top', '0px');
});
$("#size8").click(function() {
$('#Line').css('top', '0px');
});


//Updated reset button to remove new items
$("#reload").click(function () {
    value = null;
    localStorage.removeItem("userbg");
    $.cookie('lockscreenchosen', (value),{ expires: 365,  path:'/'});
    $.cookie('Mailleft', (value),{ expires: 365,  path:'/'});
    $.cookie('Mailright', (value),{ expires: 365,  path:'/'});
    $.cookie('Tweetbotleft', (value),{ expires: 365,  path:'/'});
    $.cookie('Tweetbotright', (value),{ expires: 365,  path:'/'});
    $.cookie('tweetbot', (value),{ expires: 365,  path:'/'});
    $.cookie('Phoneleft', (value),{ expires: 365,  path:'/'});
    $.cookie('Phoneright', (value),{ expires: 365,  path:'/'});
    $.cookie('Facebookleft', (value),{ expires: 365,  path:'/'});
    $.cookie('Facebookright', (value),{ expires: 365,  path:'/'});
    $.cookie('Timerleft', (value),{ expires: 365,  path:'/'});
    $.cookie('Timerright', (value),{ expires: 365,  path:'/'});
    $.cookie('Messagesleft', (value),{ expires: 365,  path:'/'});
    $.cookie('Messagesright', (value),{ expires: 365,  path:'/'});
    $.cookie('Instagramleft', (value),{ expires: 365,  path:'/'});
    $.cookie('Instagramright', (value),{ expires: 365,  path:'/'});
});



//moved bg button when clicked create Wall, Weather, Locks, and reload buttons
$("#bg").click(function () {
    closemenu();
    submenu();
    $("#bubble").css('left', '70px');
    $("#bubble").css('top', '315px');
    $("#bgwall").css('left', '4px');
    $("#nobg").css('left', '0px');
    $("#bgwall").css('top', '80px');
$("<button></button>").attr('id','wall' ).appendTo('body');    
      $("#wall").css('color', 'black');
      $("#wall").css('border', '0');
      $("#wall").css('left', '10px');
      $("#wall").css('margin-top', '20px');
      $("#wall").css('background-color', 'white');
      $("#wall").css('top', '300px');
      $("#wall").css('borderRadius', '5px');
      $("#wall").css('width', '50px');
      $("#wall").css('position', 'absolute');
      $("#wall").css('z-index', '100');
      $("#wall").css('opacity', '0.6');
      $("#wall").html('Walls').button('wall');
$("<button></button>").attr('id','weatherbutton' ).appendTo('body');    
      $("#weatherbutton").css('color', 'black');
      $("#weatherbutton").css('border', '0');
      $("#weatherbutton").css('left', '10px');
      $("#weatherbutton").css('margin-top', '20px');
      $("#weatherbutton").css('background-color', 'white');
      $("#weatherbutton").css('top', '40px');
      $("#weatherbutton").css('borderRadius', '5px');
      $("#weatherbutton").css('width', '70px');
      $("#weatherbutton").css('position', 'absolute');
      $("#weatherbutton").css('z-index', '100');
      $("#weatherbutton").css('opacity', '0.6');
      $("#weatherbutton").html('Weather').button('weatherbutton');
$("<button></button>").attr('id','locks' ).appendTo('body');    
      $("#locks").css('color', 'black');
      $("#locks").css('border', '0');
      $("#locks").css('left', '100px');
      $("#locks").css('margin-top', '20px');
      $("#locks").css('background-color', 'white');
      $("#locks").css('top', '40px');
      $("#locks").css('borderRadius', '5px');
      $("#locks").css('width', '70px');
      $("#locks").css('position', 'absolute');
      $("#locks").css('z-index', '100');
      $("#locks").css('opacity', '0.6');
      $("#locks").html('Locks').button('locks');
$("<button></button>").attr('id','reloadbg' ).appendTo('body');    
      $("#reloadbg").css('color', 'black');
      $("#reloadbg").css('border', '0');
      $("#reloadbg").css('left', '180px');
      $("#reloadbg").css('margin-top', '0px');
      $("#reloadbg").css('background-color', 'white');
      $("#reloadbg").css('top', '40px');
      $("#reloadbg").css('borderRadius', '5px');
      $("#reloadbg").css('width', '20px');
      $("#reloadbg").css('position', 'absolute');
      $("#reloadbg").css('z-index', '100');
      $("#reloadbg").css('opacity', '0.6');
      $("#reloadbg").html('&#x21bb;').button('reloadbg');
});

//when any of these are pressed reset blur
$('#widgetone, #widgettwo,#widgetthree,#widgetfour,#closewidget1,#closewidget2,#closewidget3').live('click', function() {
 releaseblur();
    }); 

// release blur function 
function releaseblur(){
opened ="1";
     $("#city").css('-webkit-filter', 'blur(0px)');
     $("#pagewrap").css('-webkit-filter', 'blur(0px)');
     $("#weather").css('-webkit-filter', 'blur(0px)');
     $("#Time").css('-webkit-filter', 'blur(0px)');
     
}

// if wall is clicked load blog
$('#wall').live('click', function() {
    alert("Please wait for page to load, you can scale items and then take a screenshot to use as wallpaper")
    window.location = 'http://ithemeiphone5s.blogspot.com/2013/10/lockbuilder-wallpapers.html'
  return false;
    }); 

// if weather button is press then remove user background and reload.
$('#weatherbutton').live('click', function() {
    localStorage.removeItem("userbg");
    location.reload();
}); 

//Reload button for locks entered
$('#reloadbg').live('click', function() {
   location.reload();
}); 





opened = "1";
// If closed remove blur and buttons
$("#settingsclose").click(function () {
   closemenu();
   $("#city").css('-webkit-filter', 'blur(0px)');
   $("#pagewrap").css('-webkit-filter', 'blur(0px)');

 $("#overlay").css('-webkit-filter', 'blur(0px)');
    $(".usersettings").css('left', '-1000px');
    $("#bgwall").css('left', '-1000px');
        $("#bubble").css('left', '-1000px');
    $(".settingspanelcolors").css('left', '1000px');
    $(".fontcolors").css('left', '1000px');
    $("#widgetfour").css('left', '-1000px');
    $("#widgetthree").css('left', '-1000px');
    $("#widgetsmenu").css('left', '-1000px');
    $("#widgetone").css('left', '-1000px');
    $("#widgettwo").css('left', '-1000px');
    $("#widgetclosemenu").css('left', '-1000px');
    $("#settingsclose").css('left', '-1000px');
    $(".settingspanel").css('left', '-1000px');
    $(".settingspanelfonts").css('left', '-1000px');
    $("#settingspanel").css('left', '-1000px');
    $(".onandoff").css('left', '-1000px');
    $(".fonton").css('left', '-50px');
    $(".settingspaneliconsgo").css('left', '-1000px');
    $(".iconsgo").css('left', '-50px');
    $("#themes").css('left', '-800px');

   $("#city").css('-webkit-filter', 'blur(0px)');
   $("#pagewrap").css('-webkit-filter', 'blur(0px)');
   $("#weather").css('-webkit-filter', 'blur(0px)');
   $("#Time").css('-webkit-filter', 'blur(0px)');


opened ="1";
   $("#refreshs").remove();
   $("#changeicons").remove();
   $("#wall").remove();
   $("#weatherbutton").remove();
   $("#locks").remove();
   $("#reloadbg").remove();
});



// When menu button is pressed
$("#opensettings").click(function () {

  opened++

//create button
if(opened =="2"){
   $(" <button></button>").attr('id','refreshs' ).appendTo('body');    
      $("#refreshs").css('color', 'black');
      $("#refreshs").css('border', '0');
      $("#refreshs").css('left', '70px');
      $("#refreshs").css('margin-top', '0px');
      $("#refreshs").css('background-color', 'white');
      $("#refreshs").css('top', '300px');
      $("#refreshs").css('borderRadius', '5px');
      $("#refreshs").css('width', '50px');
      $("#refreshs").css('position', 'absolute');
      $("#refreshs").css('z-index', '100');
      $("#refreshs").css('opacity', '0.6');
      $("#refreshs").html('Update').button('refresh');
  }
//if pressed again remove button
if(opened =="3"){

   opened ="1";
   $("#refreshs").remove();
}
});
/////////////////////////////////////////

   $('#refreshs').live('click', function() {
    
location.reload();

    }); 

// Pulled in from button.js when ever there is a sub menu open blur items.
function submenu(){
 $("#refreshs").remove(); // remove our button
  $("#Time").css('-webkit-filter', 'blur(5px)');
 
$("#city").css('-webkit-filter', 'blur(5px)');
$("#pagewrap").css('-webkit-filter', 'blur(5px)');
$("#weather").css('-webkit-filter', 'blur(5px)');

$("#settingspanel").css('left', '0px');
$("#settingspanel").css('top', '40px');
$("#settingsclose").css('left', '148px');
}


 if (navigator.platform === 'iPad') {
 $('meta[name=viewport]').attr('content','width=700, height=1000, initial-scale=2.4, maximum-scale=2.4, user-scalable=no');
   


setTimeout('locksload()', 100);

function locksload(){
$('#locksa').css("-webkit-transform","scale(0.43,0.43)");
$('#locksa').css("marginLeft","-89px");
$('#locksa').css("marginTop","-66px");
$('#locksa').css("opacity","1");
$('#locksa').animate({
    marginLeft: -89,
    marginTop: -66
    // Comment the line below to see difference
   ,opacity: 1
}, 1);

}


 }






