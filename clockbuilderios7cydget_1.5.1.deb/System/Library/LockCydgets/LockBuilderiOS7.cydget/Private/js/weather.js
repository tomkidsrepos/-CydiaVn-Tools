




if ($.cookie('ifilecookie') == null) {
  var locale = prompt("What is your zip code or woeid number? You must enter a ZipCode or Woeid. To get your woeid visit settings from the menu for the link." , "");
 $.cookie('ifilecookie', (locale),{ expires: 365,  path:'/'});

}
else {

}    

if ($.cookie('cfcookie') == null) {
  var isCelsius = confirm('Do you want celsius?'); 
 $.cookie('cfcookie', (isCelsius),{ expires: 365,  path:'/'});

}
else {
var isCelsius = true;
}  

if ($.cookie('urlwidget') == null) {
  var urlcode = confirm('Press ok if you entered woeid, press cancel for zipcode.');
 
if(urlcode == true){
  urlcode = "w";
 $.cookie('urlwidget', (urlcode),{ expires: 365,  path:'/'});
 load();
}
else{
   urlcode = "z";
 $.cookie('urlwidget', (urlcode),{ expires: 365,  path:'/'});
 load();
}

}
else {

load();
}  


// Update for cydget 



 //Keypad Codes leave the // in front of this comment

var isCelsius = $.cookie('cfcookie');
var url= $.cookie("zipcookie");
var locale = $.cookie("ifilecookie");
//alert(isCelsius);
//alert(url);
//alert(locale);


               // US Zip Codes leave the // in front of this comment
//var locale= "38671";
//var isCelsius = false;
//var url ="http://weather.yahooapis.com/forecastrss?u=f&p=";



              // Woeid Codes leave the // in front of this comment
//var locale= "2496964";
//var isCelsius = true;
//var url = "http://weather.yahooapis.com/forecastrss?w=";




var gps = false;
var useRealFeel = false; //true|false
var enableWallpaper = true; //true|false
var enableLockScreen =  true; //true|false
var stylesheetWall = 'LockScreen' 
var stylesheetLock = 'LockScreen' 
var iconSetWall = 'Icons' 
var iconExtWall = ".png"
var iconSetLock = 'Icons'
var iconSetLock2 = 'stardock'
var iconExtLock = '.jpg'
var iconExtLock2 = '.png'
var source = 'yahooWeather'
var updateInterval = 15  
var postal;
var demoMode = false;
var enabled;
if (location.href.indexOf("LockBackground")  == -1){
  stylesheet = stylesheetWall;
  iconSet = iconSetWall;
  iconExt = iconExtWall;
  enabled = enableWallpaper;

}else{
  stylesheet = stylesheetLock;
  iconSet = iconSetLock;
  iconExt = iconExtLock;
  iconSet2 = iconSetLock2;
  iconExt2 = iconExtLock2;
  enabled = enableLockScreen;
}
if(enabled == true){
if(iconSet == null || iconSet == 'null' || iconSet == ""){
  var iconSet = stylesheet;

}
var headID = document.getElementsByTagName("head")[0];     
var styleNode = document.createElement('link');
styleNode.type = 'text/css';
styleNode.rel = 'stylesheet';
styleNode.href = 'Stylesheets/'+stylesheet+'.css';
headID.appendChild(styleNode);
var scriptNode = document.createElement('script');
scriptNode.type = 'text/javascript';
scriptNode.src = 'Sources/'+source+'.js';
headID.appendChild(scriptNode);
}
function onLoad(){
  if (enabled == true){ 
  if (demoMode == true){
    document.getElementById("weatherIcon").src="../Private/IconSets/"+iconSet+"/"+"cloudy1"+iconExt;
    document.getElementById("weatherIcon2").src="../Private/IconSets/"+iconSet2+"/"+"cloudy1"+iconExt2;
    document.getElementById("city").innerText="Somewhere";
    document.getElementById("desc").innerText=[obj.icon];
    document.getElementById("temp").innerText="100?";
    
    
  }else{ 
  document.getElementById("weatherIcon").src="../Private/IconSets/"+iconSet+"/"+"dunno"+iconExt;
  document.getElementById("weatherIcon2").src="../Private/IconSets/"+iconSet2+"/"+"dunno"+iconExt2;
  if (gps == true) { UpdateLocation(); }
  else { validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal); }
  }}else{
    document.getElementsByTagName("body")[0].innerText='';
  }
}
function convertTemp(num)
{ 
  if (isCelsius == "true")
    return Math.round ((num - 32) * 5 / 9);
  else
    return num;
}
function setPostal(obj){
  if (obj.error == false){
    if(obj.cities.length > 0){
      postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
      document.getElementById("WeatherContainer").className = "";    
      weatherRefresherTemp();
    }else{
      document.getElementById("city").innerText="Not Found";
      document.getElementById("WeatherContainer").className = "errorLocaleNotFound";  
    }
  }else{
    document.getElementById("city").innerText=obj.errorString;
    document.getElementById("WeatherContainer").className = "errorLocaleValidate";  
    setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
  }
}
function dealWithWeather(obj){

  if (obj.error == false){
    document.getElementById("city").innerText=obj.city;
    document.getElementById("desc").innerText=descriptions[obj.icon];
    translatedesc=obj.description.toLowerCase();
    if(useRealFeel == true){
      tempValue = convertTemp(obj.realFeel);
    }else{
      tempValue = convertTemp(obj.temp)
    }
    document.getElementById("temp").innerHTML=tempValue+ "&#176;"
    document.getElementById("hi").innerHTML="H: "+convertTemp(obj.todayhigh)+ ""     
    document.getElementById("lo").innerHTML="L: "+convertTemp(obj.todaylow)+ ""
    document.getElementById("humidity").innerHTML="Humid: " + obj.humidity+"%"
    document.getElementById("WeatherContainer").className = ""; 
    
    document.getElementById("weatherIcon").src="../Private/IconSets/"+iconSet+"/"+MiniIcons[obj.icon]+iconExt;
    document.getElementById("weatherIcon2").src="../Private/IconSets/"+iconSet2+"/"+MiniIcons[obj.icon]+iconExt2;
  
    document.getElementById("WeatherContainer").className = "";    
  }else{
  document.getElementById("WeatherContainer").className = "errorWeatherDataFetch";       
  }
}
function weatherRefresherTemp(){ //this is one of my nice works so far... dont forget to find me and thank me "ibnyaffa".
  fetchWeatherData(dealWithWeather,postal);
  setTimeout(weatherRefresherTemp, 60*1000*updateInterval);
}
//"ibnyaffa"
var MiniIcons =
[
    "0",       //0  tornado
  "1",    //1 tropical storm
  "2",    //2 hurricane
  "3",    //3 severe thunderstorms
  "4",    //4 thunderstorms
  "5",    //5 mixed rain and snow
  "6",    //6 mixed rain and sleet
  "7",    //7 mixed snow and sleet
  "8",    //8 freezing drizzle
  "9",    //9 drizzle
  "10",   //10  freezing rain
  "11",   //11  showers
  "12",   //12  showers
  "13",   //13  snow flurries
  "14",   //14  light snow showers
  "15",   //15  blowing snow
  "16",   //16  snow
  "17",   //17  hail
  "18",   //18  sleet
  "19",   //19  dust
  "20",     //20  foggy
  "21",     //21  haze
  "22",     //22  smoky
  "23",   //23  blustery
  "24",   //24  windy
  "25",     //25  cold
  "26",   //26  cloudy
  "27", //27  mostly cloudy (night)
  "28",   //28  mostly cloudy (day)
  "29", //29  partly cloudy (night)
  "30",   //30  partly cloudy (day)
  "31",   //31  clear (night)
  "32",   //32  sunny
  "33", //33  fair (night)
  "34",   //34  fair (day)
  "35",   //35  mixed rain and hail
  "36",     //36  hot
  "37",   //37  isolated thunderstorms
  "38",   //38  scattered thunderstorms
  "39",   //39  scattered thunderstorms
  "40",   //40  scattered showers
  "41",   //41  heavy snow
  "42",   //42  scattered snow showers
  "43",   //43  heavy snow
  "44",   //44  partly cloudy
  "45",   //45  thundershowers
  "46",   //46  snow showers
  "47",   //47  isolated thundershowers
  "dunno",    //3200  not available
]
var descriptions =
[
"tornado",

"storm",

"hurricane",

"severe storms",

"tstorms",

"rain/snow",

"rain/sleet",

"snow/sleet",

"light rain",

"drizzle",

"sleet",

"showers",

"showers",

"flurries",

"light snow",

"snow",

"snow",

"hail",

"sleet",

"mist",

"foggy",

"haze",

"smoky",

"cold",

"windy",

"cold",

"cloudy",

"cloudy",

"cloudy",

"cloudy",

"cloudy",

"clear",

"sunny",

"fair",

"fair",

"rain/hail",

"hot",

"tstorms",

"tstorms",

"tstorms",

"showers",

"heavy snow",

"snow",

"heavy snow",

"cloudy",

"tshowers",

"snow",

"tshowers",

"n/a",

]
function constructError (string)
{
  return {error:true, errorString:string};
}
function findChild (element, nodeName)
{
  var child;
  for (child = element.firstChild; child != null; child = child.nextSibling)
  {
    if (child.nodeName == nodeName)
      return child;
  }
  return null;
}
function fetchWeatherData (callback, zip)
{
 
  //u=Farenheit, because accuWeather sucks

  var xml_request = new XMLHttpRequest();
  xml_request.onload = function(e) {xml_loaded(e, xml_request, callback);}
  xml_request.overrideMimeType("text/xml");
  xml_request.open("GET", url+zip);
  xml_request.setRequestHeader("Cache-Control", "no-cache");
  xml_request.send(null); 
  return xml_request;
}
function xml_loaded (event, request, callback)
{
  if (request.responseXML)
  {
    var obj = {error:false, errorString:null};
    xmldata = true;
    var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
    obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city");
    obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");//Only accounts for windChill
    obj.humidity = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("humidity");
    obj.windunit = findChild(effectiveRoot, "yweather:units").getAttribute("speed");  
    obj.winddir = findChild(effectiveRoot, "yweather:wind").getAttribute("direction");
    obj.windspeed = findChild(effectiveRoot, "yweather:wind").getAttribute("speed");   
    obj.sunrise = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunrise");
    obj.sunset = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunset");
    var conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
    obj.temp = conditionTag.getAttribute("temp");
    obj.icon = conditionTag.getAttribute("code");
    obj.description = conditionTag.getAttribute("text");
    var forecast = findChild(findChild(effectiveRoot, "item"), "yweather:forecast");
    obj.todaylow = forecast.getAttribute("low");
    obj.todayhigh = forecast.getAttribute("high");
    if (obj.description == "Unknown") {
      obj.description = forecast.getAttribute("text");
      obj.icon = forecast.getAttribute("code");
    }
    if (obj.icon == 3200) obj.icon = 48;
    callback (obj);
  }
  else
  {
    callback ({error:true, errorString:"XML request failed. no responseXML"});
  }
}
function validateWeatherLocation (location, callback)
{
  var obj = {error:false, errorString:null, cities: new Array};
  obj.cities[0] = {zip: location}; 
  callback (obj);
}
