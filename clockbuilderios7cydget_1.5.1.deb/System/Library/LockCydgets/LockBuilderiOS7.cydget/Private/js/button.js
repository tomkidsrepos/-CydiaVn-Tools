// button pressed on keypad
$("#setweather").click(function () {
    text = document.body.innerHTML;
    text = text.replace(/(<([^>]+)>)/ig, "");
    text = text.slice(0, 14);
    text = text.replace(/(^\s+|\s+$)/g, '');
    text = text.replace(/\s/g, "");
    $("#container").css({
        opacity: 0.0
    });
    $("#setweather").css({
        opacity: 0.0
    });
    $("#reload").css({
        opacity: 0.0
    });
    $("#dialerbg").css('top', '-1000px');
    $("#closemenu").css('left', '1000px');
    $("#woeid").css({
        opacity: 0.0
    });
    $("#zip").css({
        opacity: 0.0
    });


    if ($.cookie('ifilecookie') != null) {
        var local = $.cookie('ifilecookie');
    } else {
        $.cookie('ifilecookie', (text),{ expires: 365});
    }    location.reload();
});




//settins button drop down

click1 = "0";

$("#opensettings").click(function () {
click1++
    if(click1 == 1){ openmenu1();}
        if(click1 == 2){closemenu();click1 = "0";}
});


function openmenu1(){
$("#city").css('-webkit-filter', 'blur(5px)');
$("#pagewrap").css('-webkit-filter', 'blur(5px)');
$("#weather").css('-webkit-filter', 'blur(5px)');
$("#opensettings").css('top', '325px');

$(".menu1").css('left', '130px');

$(".menu1icons").css('left', '80px');
$("#menubar").css('top', '-80px');
}



function closemenu(){
$("#city").css('-webkit-filter', 'blur(0px)');
 $("#pagewrap").css('-webkit-filter', 'blur(0px)');
$("#weather").css('-webkit-filter', 'blur(0px)');
   click1 = "0";
$("#opensettings").css('top', '5px');


$("#menubar").css('top', '-900px');
$(".menu1icons").css('left', '-605px');
$(".menu1").css('left', '-605px');
}

// Font Menu

$("#fonts").click(function () {
closemenu();
submenu();

    $(".settingspanelfonts").css('left', '4px');
    $(".fonton").css('left', '155px');
    $(".fonton").css('top', '50px');
    $(".settingspanelfonts").css('top', '-80px');
});

function submenu(){
$("#city").css('-webkit-filter', 'blur(5px)');
 $("#pagewrap").css('-webkit-filter', 'blur(5px)');
  $("#weather").css('-webkit-filter', 'blur(5px)');

$("#settingspanel").css('left', '0px');
$("#settingspanel").css('left', '40px');
$("#settingsclose").css('left', '148px');
}

//font size

$("#iconsgo").click(function () {
    closemenu();
    submenu();
    $("#city").css('-webkit-filter', 'blur(5px)');
 $("#weather").css('-webkit-filter', 'blur(5px)');
 $("#pagewrap").css('-webkit-filter', 'blur(5px)');
    $("#settingspanel").css('left', '0px');
    $("#presstext").css('left', '-130px');
    $(".iconsgo").css('left', '160px');
    $(".iconsgo").css('top', '60px');
});


//backgrounds
$("#bg").click(function () {
    closemenu();
    submenu();
 $("#bubble").css('left', '70px');
 $("#bubble").css('top', '315px');
    $("#bgwall").css('left', '4px');
    $("#nobg").css('left', '0px');
    $("#bgwall").css('top', '80px');
});







// Weather ENTRY.

$("#settings").click(function () {
   closemenu();
  submenu();
$(".usersettings").css('top', '-60px');
      $(".usersettings").css({
        left:50
    });
 
   
 

});



//zip pressed

function load() {
    

code = $.cookie('urlwidget');

if(code == "w"){


  urlwidget = "w";
    url = "http://weather.yahooapis.com/forecastrss?w="
$.cookie('zipcookie', (url),{ expires: 365});

    if ($.cookie('zipcookie') != null) {

        var woeid = $.cookie('zipcookie');
   

    } else {
        $.cookie('zipcookie', (url),{ expires: 365});

    }

    if ($.cookie('urlwidget') != null) {
        var urlwidget = $.cookie('urlwidget');

    } else {
        $.cookie('urlwidget', (urlwidget),{ expires: 365});

    }
}


if(code =="z"){


    url = "http://weather.yahooapis.com/forecastrss?u=f&p=";
     $.cookie('zipcookie', (url),{ expires: 365});
    urlwidget = "z";

    if ($.cookie('zipcookie') != null) {
        var zip = $.cookie('zipcookie');

    } else {
        $.cookie('zipcookie', (url),{ expires: 365});

    }

    if ($.cookie('urlwidget') != null) {
        var urlwidget = $.cookie('urlwidget');

    } else {
        $.cookie('urlwidget', (urlwidget),{ expires: 365});

    }

}


};


//click woeid



$("#selectifc").click(function () {


    $.cookie("cfccookie", null);

    B = "c"

    C = "true";

    if ($.cookie('cfccookie') != null) {
        var C = $.cookie('cfcookie');
        var B = $.cookie('cfccookie')
    } else {

        $.cookie('cfccookie', (B),{ expires: 365});
        $.cookie('cfcookie', (C),{ expires: 365});
    }
});

$("#selectiff").click(function () {
    $("#selectiff").css('color', 'blue');
    $.cookie("cfccookie", null);

    D = "f"

    C = "false";

    if ($.cookie('cfccookie') != null) {
        var D = $.cookie('cfccookie');

    } else {
        $.cookie('cfccookie', (D),{ expires: 365});
        $.cookie('cfcookie', (C),{ expires: 365});
    }
});






$("#selectif24hr").click(function () {
    $("#selectif24hr").css('color', 'blue');
    $.cookie("24hrcookie", null);
    H = "false";

    if ($.cookie('24hrcookie') != null) {
        var Hf = $.cookie('24hrcookie');


    } else {
        $.cookie('24hrcookie', (H),{ expires: 365});

    }
});



$("#selectif12hr").click(function () {
    $("#selectif12hr").css('color', 'blue');
    $.cookie("24hrcookie", null);
    Hr = "true";

    if ($.cookie('24hrcookie') != null) {
        var Hd = $.cookie('24hrcookie');


    } else {
        $.cookie('24hrcookie', (Hr),{ expires: 365});

    }
});



// reset button

$("#reload").click(function () {
    
    value = null;
   
    $.cookie('ifilecookie', (value),{ expires: 365,  path:'/'});
    $.cookie('urlwidget', (value),{ expires: 365,  path:'/'});
    $.cookie('cfcookie', (value),{ expires: 365,  path:'/'});
    $.cookie('hor', (value),{ expires: 365,  path:'/'});
    $.cookie('ver', (value),{ expires: 365,  path:'/'});
    $.cookie('blur', (value),{ expires: 365,  path:'/'});
    $.cookie('cc', (value),{ expires: 365,  path:'/'});
     $.cookie("ifilecookie", (value),{ expires: 365,  path:'/'});
    $.cookie("widget2", (value),{ expires: 365,  path:'/'});
    $.cookie("closewidget", (value),{ expires: 365,  path:'/'});
    $.cookie("widget1", (value),{ expires: 365,  path:'/'});
    $.cookie("zipcookie", (value),{ expires: 365,  path:'/'});
    $.cookie("zipcook", (value),{ expires: 365,  path:'/'});
    $.cookie("urlwidget", (value),{ expires: 365,  path:'/'});
    $.cookie("descriptionright", (value),{ expires: 365,  path:'/'});
    $.cookie("descriptionleft", (value),{ expires: 365,  path:'/'});
    $.cookie("yourcityleft", (value),{ expires: 365,  path:'/'});
    $.cookie("yourcityright", (value),{ expires: 365,  path:'/'});
    $.cookie("iconsgo", (value),{ expires: 365,  path:'/'});
    $.cookie("cfcookie", (value),{ expires: 365,  path:'/'});
    $.cookie("24hrcookie", (value),{ expires: 365,  path:'/'});
    $.cookie('widget1left', (value),{ expires: 365,  path:'/'});
    $.cookie('widget1right', (value),{ expires: 365,  path:'/'});
    $.cookie('datestate', (value),{ expires: 365,  path:'/'});
    $.cookie('fontstate', (value),{ expires: 365,  path:'/'});
    $.cookie('symbol', (value),{ expires: 365,  path:'/'});
    $.cookie("iconsgo", (value),{ expires: 365,  path:'/'});
    $.cookie("cfcookie", (value),{ expires: 365,  path:'/'});
    $.cookie("24hrcookie", (value),{ expires: 365,  path:'/'});
    $.cookie('widget1left', (value),{ expires: 365,  path:'/'});
    $.cookie('widget1right', (value),{ expires: 365,  path:'/'});
    $.cookie('datestate', (value),{ expires: 365,  path:'/'});
    $.cookie('fontstate', (value),{ expires: 365,  path:'/'});
    $.cookie('symbol', (value),{ expires: 365,  path:'/'});
    $.cookie('timestate', (value),{ expires: 365,  path:'/'});
    $.cookie('wallcook', (value),{ expires: 365,  path:'/'});
    $.cookie('wallcookoverlay', (value),{ expires: 365,  path:'/'});
    $.cookie('rotated', (value),{ expires: 365,  path:'/'});
    $.cookie('buttoncook', (value),{ expires: 365,  path:'/'});
    $.cookie('iconstate', (value),{ expires: 365,  path:'/'});
    $.cookie('tempstate', (value),{ expires: 365,  path:'/'});
    $.cookie('descstate', (value),{ expires: 365,  path:'/'});
    $.cookie('humidstate', (value),{ expires: 365,  path:'/'});
    $.cookie('datestate', (value),{ expires: 365,  path:'/'});
    $.cookie('highstate', (value),{ expires: 365,  path:'/'});
    $.cookie('lowstate', (value),{ expires: 365,  path:'/'});
     $.cookie('templeft', (value),{ expires: 365,  path:'/'});
    $.cookie('tempright', (value),{ expires: 365,  path:'/'});
     $.cookie('degreesleft', (value),{ expires: 365,  path:'/'});
    $.cookie('degreesright', (value),{ expires: 365,  path:'/'});
    $.cookie('lowleft', (value),{ expires: 365,  path:'/'});
    $.cookie('lowright', (value),{ expires: 365,  path:'/'});
    $.cookie('highleft', (value),{ expires: 365,  path:'/'});
    $.cookie('highright', (value),{ expires: 365,  path:'/'});
    $.cookie('weatherIcon2left', (value),{ expires: 365,  path:'/'});
    $.cookie('weatherIcon2right', (value),{ expires: 365,  path:'/'});
    $.cookie('calleft', (value),{ expires: 365,  path:'/'});
    $.cookie('calright', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgo', (value),{ expires: 365,  path:'/'});
    $.cookie('temp', (value),{ expires: 365,  path:'/'});
    $.cookie('timeleft', (value),{ expires: 365,  path:'/'});
    $.cookie('timeright', (value),{ expires: 365,  path:'/'});
    $.cookie('colorstate', (value),{ expires: 365,  path:'/'});
    $.cookie('timestate', (value),{ expires: 365,  path:'/'});
    $.cookie('urlwidget', (value),{ expires: 365,  path:'/'});
    $.cookie('closewidget3', (value),{ expires: 365,  path:'/'});
    $.cookie('widget3', (value),{ expires: 365,  path:'/'});
    $.cookie('citystate', (value),{ expires: 365,  path:'/'});
    $.cookie('closewidget1', (value),{ expires: 365,  path:'/'});
    $.cookie('clock', (value),{ expires: 365,  path:'/'});
    $.cookie('widget4', (value),{ expires: 365,  path:'/'});
    $.cookie('widget4onoff', (value),{ expires: 365,  path:'/'});
    $.cookie('widget4left', (value),{ expires: 365,  path:'/'});
    $.cookie('widget4right', (value),{ expires: 365,  path:'/'});
    $.cookie('widget4on', (value),{ expires: 365,  path:'/'});
    $.cookie('humidleft', (value),{ expires: 365,  path:'/'});
    $.cookie('humidright', (value),{ expires: 365,  path:'/'});
    $.cookie('widget2left', (value),{ expires: 365,  path:'/'});
    $.cookie('widget2right', (value),{ expires: 365,  path:'/'});
    $.cookie('rotatedwithgesture', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgowithgesture', (value),{ expires: 365,  path:'/'});
     $.cookie('rotatedwithgesturetemp', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgowithgesturetemp', (value),{ expires: 365,  path:'/'});
     $.cookie('rotatedwithgesturehumidity', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgowithgesturehumidity', (value),{ expires: 365,  path:'/'});
     $.cookie('rotatedwithgesturedesc', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgowithgesturedesc', (value),{ expires: 365,  path:'/'});
     $.cookie('rotatedwithgesturedate', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgowithgesturedate', (value),{ expires: 365,  path:'/'});
     $.cookie('rotatedwithgesturecalendar', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgowithgesturecalendar', (value),{ expires: 365,  path:'/'});
     $.cookie('rotatedwithgesturehi', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgowithgesturehi', (value),{ expires: 365,  path:'/'});
     $.cookie('rotatedwithgesturelow', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgowithgesturelow', (value),{ expires: 365,  path:'/'});
     $.cookie('rotatedwithgestureweathericon', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgowithgestureweathericon', (value),{ expires: 365,  path:'/'});
     $.cookie('rotatedwithgesturetime', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgowithgesturetime', (value),{ expires: 365,  path:'/'});
     $.cookie('rotatedwithgestureclock', (value),{ expires: 365,  path:'/'});
    $.cookie('iconsgowithgestureclock', (value),{ expires: 365,  path:'/'});
     location.reload();

  

});

// On off switches weather

$("#settingsmain").click(function () {
   closemenu();
  submenu();
    $(".settingspanel").css('left', '5px');
        $(".settingspanel").css('top', '-80px');
 

    $(".onandoff").css('left', '0px');
      $(".onandoff").css('top', '-80px');
});




// close button

