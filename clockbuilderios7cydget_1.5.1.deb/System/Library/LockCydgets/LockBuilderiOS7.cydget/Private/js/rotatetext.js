



 
$('#Tweetbot').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "100"; var rotation = 0;
    $('#Tweetbot').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturetweetbot', $("#Tweetbot").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Tweetbot").css('width'),{ expires: 365});
    e.preventDefault();
    $(this).css("width", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturetweetbot', $("#Tweetbot").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Tweetbot").css('width'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturetweetbot') != null) {
        $('#Tweetbot').css('-webkit-transform', $.cookie('rotatedwithgesturetweetbot'),{ expires: 365});

        
} 

    if ($.cookie('withtweetgesture') != null) {
        $('#Tweetbot').css('font-size', $.cookie('withtweetgesture'),{ expires: 365});
        
} 

$('#Phone').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#Phone').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturePhone', $("#Phone").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Phone").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturePhone', $("#Phone").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Phone").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturePhone') != null) {
        $('#Phone').css('-webkit-transform', $.cookie('rotatedwithgesturePhone'),{ expires: 365});

        
} 

    if ($.cookie('withtweetgesture') != null) {
        $('#Phone').css('font-size', $.cookie('withtweetgesture'),{ expires: 365});
        
} 



$('#Mail').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#Mail').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgestureMail', $("#Mail").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Mail").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgestureMail', $("#Mail").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Mail").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgestureMail') != null) {
        $('#Mail').css('-webkit-transform', $.cookie('rotatedwithgestureMail'),{ expires: 365});

        
} 

    if ($.cookie('withtweetgesture') != null) {
        $('#Mail').css('font-size', $.cookie('withtweetgesture'),{ expires: 365});
        
} 



$('#Facebook').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#Facebook').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgestureFacebook', $("#Facebook").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Facebook").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgestureFacebook', $("#Facebook").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Facebook").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgestureFacebook') != null) {
        $('#Facebook').css('-webkit-transform', $.cookie('rotatedwithgestureFacebook'),{ expires: 365});

        
} 

    if ($.cookie('withtweetgesture') != null) {
        $('#Facebook').css('font-size', $.cookie('withtweetgesture'),{ expires: 365});
        
} 



$('#Timer').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#Timer').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgestureTimer', $("#Timer").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Timer").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgestureTimer', $("#Timer").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Timer").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgestureTimer') != null) {
        $('#Timer').css('-webkit-transform', $.cookie('rotatedwithgestureTimer'),{ expires: 365});

        
} 

    if ($.cookie('withtweetgesture') != null) {
        $('#Timer').css('font-size', $.cookie('withtweetgesture'),{ expires: 365});
        
} 



$('#Messages').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#Messages').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgestureMessages', $("#Messages").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Messages").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgestureMessages', $("#Messages").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Messages").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgestureMessages') != null) {
        $('#Messages').css('-webkit-transform', $.cookie('rotatedwithgestureMessages'),{ expires: 365});

        
} 

    if ($.cookie('withtweetgesture') != null) {
        $('#Messages').css('font-size', $.cookie('withtweetgesture'),{ expires: 365});
        
} 

$('#Instagram').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#Instagram').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgestureInstagram', $("#Instagram").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Instagram").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgestureInstagram', $("#Instagram").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Instagram").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgestureInstagram') != null) {
        $('#Instagram').css('-webkit-transform', $.cookie('rotatedwithgestureInstagram'),{ expires: 365});

        
} 

    if ($.cookie('withtweetgesture') != null) {
        $('#Instagram').css('font-size', $.cookie('withtweetgesture'),{ expires: 365});
        
} 

$('#Line').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#Line').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgestureLine', $("#Line").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Line").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgestureLine', $("#Line").css('-webkit-transform'),{ expires: 365});
    $.cookie('withtweetgesture', $("#Line").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgestureLine') != null) {
        $('#Line').css('-webkit-transform', $.cookie('rotatedwithgestureLine'),{ expires: 365});

        
} 

    if ($.cookie('withtweetgesture') != null) {
        $('#Line').css('font-size', $.cookie('withtweetgesture'),{ expires: 365});
        
} 

$('#city').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#city').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesture', $("#city").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesture', $("#city").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesture', $("#city").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesture', $("#city").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesture') != null) {
        $('#city').css('-webkit-transform', $.cookie('rotatedwithgesture'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesture') != null) {
        $('#city').css('font-size', $.cookie('fontsizewithgesture'),{ expires: 365});
        
} 



//wind


$('#wind').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "30px"; var rotation = 0;
    $('#wind').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturewind', $("#wind").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturewind', $("#wind").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturewind', $("#wind").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturewind', $("#wind").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(font) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturewind') != null) {
        $('#wind').css('-webkit-transform', $.cookie('rotatedwithgesturewind'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesturewind') != null) {
        $('#wind').css('font-size', $.cookie('fontsizewithgesturewind'),{ expires: 365});
        
} 


//sunuptext


$('#sunuptext').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#sunuptext').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturesunuptext', $("#sunuptext").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturesunuptext', $("#sunuptext").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturesunuptext', $("#sunuptext").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturesunuptext', $("#sunuptext").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturesunuptext') != null) {
        $('#sunuptext').css('-webkit-transform', $.cookie('rotatedwithgesturesunuptext'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesturesunuptext') != null) {
        $('#sunuptext').css('font-size', $.cookie('fontsizewithgesturesunuptext'),{ expires: 365});
        
} 

//sundowntext


$('#sundowntext').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#sundowntext').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturesundowntext', $("#sundowntext").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturesundowntext', $("#sundowntext").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturesundowntext', $("#sundowntext").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturesundowntext', $("#sundowntext").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturesundowntext') != null) {
        $('#sundowntext').css('-webkit-transform', $.cookie('rotatedwithgesturesundowntext'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesturesundowntext') != null) {
        $('#sundowntext').css('font-size', $.cookie('fontsizewithgesturesundowntext'),{ expires: 365});
        
} 

//sunrise


$('#sunrise').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#sunrise').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturesunrise', $("#sunrise").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturesunrise', $("#sunrise").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturesunrise', $("#sunrise").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturesunrise', $("#sunrise").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturesunrise') != null) {
        $('#sunrise').css('-webkit-transform', $.cookie('rotatedwithgesturesunrise'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesturesunrise') != null) {
        $('#sunrise').css('font-size', $.cookie('fontsizewithgesturesunrise'),{ expires: 365});
        
} 

//sunset


$('#sunset').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#sunset').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturesunset', $("#sunset").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturesunset', $("#sunset").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturesunset', $("#sunset").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturesunset', $("#sunset").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturesunset') != null) {
        $('#sunset').css('-webkit-transform', $.cookie('rotatedwithgesturesunset'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesturesunset') != null) {
        $('#sunset').css('font-size', $.cookie('fontsizewithgesturesunset'),{ expires: 365});
        
} 

//temp


$('#temp').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
   
});

var font = "25px"; var rotation = 0;
    $('#temp').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturetemp', $("#temp").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturetemp', $("#temp").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturetemp', $("#temp").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturetemp', $("#temp").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturetemp') != null) {
        $('#temp').css('-webkit-transform', $.cookie('rotatedwithgesturetemp'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesturetemp') != null) {
        $('#temp').css('font-size', $.cookie('fontsizewithgesturetemp'),{ expires: 365});
        
} 


//humidity


$('#humidity').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
   
});

var font = "25px"; var rotation = 0;
    $('#humidity').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturehumidity', $("#humidity").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturehumidity', $("#humidity").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturehumidity', $("#humidity").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturehumidity', $("#humidity").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturehumidity') != null) {
        $('#humidity').css('-webkit-transform', $.cookie('rotatedwithgesturehumidity'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesturehumidity') != null) {
        $('#humidity').css('font-size', $.cookie('fontsizewithgesturehumidity'),{ expires: 365});
        
} 

//desc


$('#desc').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
  
});

var font = "25px"; var rotation = 0;
    $('#desc').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturedesc', $("#desc").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturedesc', $("#desc").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturedesc', $("#desc").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturedesc', $("#desc").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturedesc') != null) {
        $('#desc').css('-webkit-transform', $.cookie('rotatedwithgesturedesc'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesturedesc') != null) {
        $('#desc').css('font-size', $.cookie('fontsizewithgesturedesc'),{ expires: 365});
        
} 



//date


//calendar


$('#calendar').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#calendar').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturecalendar', $("#calendar").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturecalendar', $("#calendar").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturecalendar', $("#calendar").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturecalendar', $("#calendar").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturecalendar') != null) {
        $('#calendar').css('-webkit-transform', $.cookie('rotatedwithgesturecalendar'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesturecalendar') != null) {
        $('#calendar').css('font-size', $.cookie('fontsizewithgesturecalendar'),{ expires: 365});
        
} 

//hi


$('#hi').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#hi').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturehi', $("#hi").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturehi', $("#hi").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturehi', $("#hi").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturehi', $("#hi").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturehi') != null) {
        $('#hi').css('-webkit-transform', $.cookie('rotatedwithgesturehi'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesturehi') != null) {
        $('#hi').css('font-size', $.cookie('fontsizewithgesturehi'),{ expires: 365});
        
} 

//lo



$('#low').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var font = "25px"; var rotation = 0;
    $('#low').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgesturelow', $("#low").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturelow', $("#low").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgesturelow', $("#low").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgesturelow', $("#low").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgesturelow') != null) {
        $('#low').css('-webkit-transform', $.cookie('rotatedwithgesturelow'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgesturelow') != null) {
        $('#low').css('font-size', $.cookie('fontsizewithgesturelow'),{ expires: 365});
        
} 


//weathericon

$('#weatherIcon2').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;

});

var width = "100"; var rotation = 0;
    $('#weatherIcon2').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgestureweathericon', $("#weatherIcon2").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgestureweathericon', $("#weatherIcon2").css('width'),{ expires: 365});
    e.preventDefault();
    $(this).css("width", parseFloat(width) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgestureweathericon', $("#weatherIcon2").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgestureweathericon', $("#weatherIcon2").css('width'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgestureweathericon') != null) {
        $('#weatherIcon2').css('-webkit-transform', $.cookie('rotatedwithgestureweathericon'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgestureweathericon') != null) {
        $('#weatherIcon2').css('width', $.cookie('fontsizewithgestureweathericon'),{ expires: 365});
        
} 








//clock




$('#clock').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
   
});

var font = "25px"; var rotation = 0;
    $('#clock').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     $.cookie('rotatedwithgestureclock', $("#clock").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgestureclock', $("#clock").css('font-size'),{ expires: 365});
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
else if(e.type == 'gestureend'){
    $.cookie('rotatedwithgestureclock', $("#clock").css('-webkit-transform'),{ expires: 365});
    $.cookie('fontsizewithgestureclock', $("#clock").css('font-size'),{ expires: 365});


    a.w[ids] = parseFloat(width) * orig.scale;
    a.rotation[ids] = (parseFloat(rotation) + orig.rotation) % 360;
}
});

    if ($.cookie('rotatedwithgestureclock') != null) {
        $('#clock').css('-webkit-transform', $.cookie('rotatedwithgestureclock'),{ expires: 365});

        
} 

    if ($.cookie('fontsizewithgestureclock') != null) {
        $('#clock').css('font-size', $.cookie('fontsizewithgestureclock'),{ expires: 365});
        
} 


//Languages

 $("#langen").click(function () {

location.reload();


$.cookie('langcookie', "en",{ expires: 365});


 });

 $("#langfr").click(function () {

location.reload();


$.cookie('langcookie', "fr",{ expires: 365});


 });

  $("#langde").click(function () {

location.reload();


$.cookie('langcookie', "de",{ expires: 365});


 });

   $("#langsp").click(function () {

location.reload();


$.cookie('langcookie', "sp",{ expires: 365});


 });

    $("#langit").click(function () {

location.reload();


$.cookie('langcookie', "it",{ expires: 365});


 });

 