$(window).load(function(){
jQuery.cookie = function (key, value, options) {

    // key and at least value given, set cookie...
    if (arguments.length > 1 && String(value) !== "[object Object]") {
  options = jQuery.extend({}, options);

  if (value === null || value === undefined) {
      options.expires = -1;
  }

  if (typeof options.expires === 'number') {
      var days = options.expires, t = options.expires = new Date();
      t.setDate(t.getDate() + days);
  }

  value = String(value);

  return (document.cookie = [
      encodeURIComponent(key), '=',
      options.raw ? value : encodeURIComponent(value),
      options.expires ? '; expires=' + options.expires.toUTCString() : '', 
      options.path ? '; path=' + options.path : '',
      options.domain ? '; domain=' + options.domain : '',
      options.secure ? '; secure' : ''
  ].join(''));
    }

    options = value || {};
    var result, decode = options.raw ? function (s) { return s; } : decodeURIComponent;
    return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null;
};


$('#reload').click( function() {
$.cookie('colorstate', $("#background").css('background-color'),{ expires: 365,  path:'/'});
  window.parent.refreshing();
}); 






$('#dropshadow').click( function() {

   value = null;
   
    $.cookie('hor', (value),{ expires: 365,  path:'/'});
    $.cookie('ver', (value),{ expires: 365,  path:'/'});
    $.cookie('blur', (value),{ expires: 365,  path:'/'});
    $.cookie('cc', (value),{ expires: 365,  path:'/'});
        $.cookie('hor2', (value),{ expires: 365,  path:'/'});
    $.cookie('ver2', (value),{ expires: 365,  path:'/'});
    $.cookie('blur2', (value),{ expires: 365,  path:'/'});
    $.cookie('cc2', (value),{ expires: 365,  path:'/'});
        $.cookie('hor3', (value),{ expires: 365,  path:'/'});
    $.cookie('ver3', (value),{ expires: 365,  path:'/'});
    $.cookie('blur3', (value),{ expires: 365,  path:'/'});
    $.cookie('cc3', (value),{ expires: 365,  path:'/'});
    $.cookie('oneshadow', (value),{ expires: 365,  path:'/'});



if ($.cookie('hor') == null) {
   var oneshadow = prompt("How many shadows?" , "");
 $.cookie('oneshadow', (oneshadow),{ expires: 365,  path:'/'});
}

if($.cookie('oneshadow') == "1"){

 one();
}
if($.cookie('oneshadow') == "2"){

two();
}
if($.cookie('oneshadow') == "3"){

 three();
}

});  


});  


function one(){

  var hor = prompt("(1)Enter a number you want the shadow to move horizontally" , "");
 $.cookie('hor', (hor),{ expires: 365,  path:'/'});
 var ver = prompt("(1)Enter a number you want the shadow to move vertically" , "");
 $.cookie('ver', (ver),{ expires: 365,  path:'/'});
  var blur = prompt("(1)Enter a number you want the shadow to blur" , "");
 $.cookie('blur', (blur),{ expires: 365,  path:'/'});
  var cc = prompt("(1)Enter a color or color code" , "");
 $.cookie('cc', (cc),{ expires: 365,  path:'/'});
  window.parent.setshadows();


}

function two(){

  var hor = prompt("(1)Enter a number you want the shadow to move horizontally" , "");
 $.cookie('hor', (hor),{ expires: 365,  path:'/'});
 var ver = prompt("(1)Enter a number you want the shadow to move vertically" , "");
 $.cookie('ver', (ver),{ expires: 365,  path:'/'});
  var blur = prompt("(1)Enter a number you want the shadow to blur" , "");
 $.cookie('blur', (blur),{ expires: 365,  path:'/'});
  var cc = prompt("(1)Enter a color or color code" , "");
 $.cookie('cc', (cc),{ expires: 365,  path:'/'});



  var hor2 = prompt("(2)Enter a number you want the shadow to move horizontally" , "");
 $.cookie('hor2', (hor2),{ expires: 365,  path:'/'});
 var ver2 = prompt("(2)Enter a number you want the shadow to move vertically" , "");
 $.cookie('ver2', (ver2),{ expires: 365,  path:'/'});
  var blur2 = prompt("(2)Enter a number you want the shadow to blur" , "");
 $.cookie('blur2', (blur2),{ expires: 365,  path:'/'});
  var cc2 = prompt("(2)Enter a color or color code" , "");
 $.cookie('cc2', (cc2),{ expires: 365,  path:'/'});
  window.parent.setshadows();


}

function three(){


  var hor = prompt("(1)Enter a number you want the shadow to move horizontally" , "");
 $.cookie('hor', (hor),{ expires: 365,  path:'/'});
 var ver = prompt("(1)Enter a number you want the shadow to move vertically" , "");
 $.cookie('ver', (ver),{ expires: 365,  path:'/'});
  var blur = prompt("(1)Enter a number you want the shadow to blur" , "");
 $.cookie('blur', (blur),{ expires: 365,  path:'/'});
  var cc = prompt("(1)Enter a color or color code" , "");
 $.cookie('cc', (cc),{ expires: 365,  path:'/'});



  var hor2 = prompt("(2)Enter a number you want the shadow to move horizontally" , "");
 $.cookie('hor2', (hor2),{ expires: 365,  path:'/'});
 var ver2 = prompt("(2)Enter a number you want the shadow to move vertically" , "");
 $.cookie('ver2', (ver2),{ expires: 365,  path:'/'});
  var blur2 = prompt("(2)Enter a number you want the shadow to blur" , "");
 $.cookie('blur2', (blur2),{ expires: 365,  path:'/'});
  var cc2 = prompt("(2)Enter a color or color code" , "");
 $.cookie('cc2', (cc2),{ expires: 365,  path:'/'});
  var hor3 = prompt("(3)Enter a number you want the shadow to move horizontally" , "");
 $.cookie('hor3', (hor3),{ expires: 365,  path:'/'});
 var ver3 = prompt("(3)Enter a number you want the shadow to move vertically" , "");
 $.cookie('ver3', (ver3),{ expires: 365,  path:'/'});
  var blur3 = prompt("(3)Enter a number you want the shadow to blur" , "");
 $.cookie('blur3', (blur3),{ expires: 365,  path:'/'});
  var cc3 = prompt("(3)Enter a color or color code" , "");
 $.cookie('cc3', (cc3),{ expires: 365,  path:'/'});
  window.parent.setshadows();


}

