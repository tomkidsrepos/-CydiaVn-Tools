diffuse=vec4(1,1,1,1)material={[0]={shader="earth",uniforms={modelViewMatrix=vars.modelViewMatrix,projectionMatrix=vars.projectionMatrix,normalMatrix=vars.modelViewMatrix.inverse.transposed,diffuseColor=diffuse*vars.lightDiffuse*vars.lightIntensity,lightPosition=vars.lightPosition,tex="earth",night="night",}}}local i=material[0].uniforms
local a=material[0]if options.normalMap then
i.nMap="earth.nmap"a.shader=a.shader.."[normal_map]"end
if options.specular then
a.shader=a.shader.."[specular]"end
if options.night then
a.shader=a.shader.."[night_map]"end
